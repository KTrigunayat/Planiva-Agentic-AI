"""
MCP (Message Control Plane) Server for inter-agent communication
Uses Redis Pub/Sub and Streams for reliable message delivery
"""

import asyncio
import json
import redis.asyncio as redis
from typing import Dict, Any, Callable, List
from datetime import datetime
import logging
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
import os

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class MCPServer:
    """
    Message Control Plane Server for Planiva
    Handles pub/sub messaging between agents
    """
    
    def __init__(self, redis_url: str = None):
        """Initialize MCP Server"""
        self.redis_url = redis_url or os.getenv("REDIS_URL", "redis://localhost:6379/0")
        self.redis_client = None
        self.pubsub = None
        self.subscribers: Dict[str, List[Callable]] = {}
        self.active_websockets: List[WebSocket] = []
        
    async def connect(self):
        """Connect to Redis"""
        self.redis_client = await redis.from_url(
            self.redis_url,
            encoding="utf-8",
            decode_responses=True
        )
        self.pubsub = self.redis_client.pubsub()
        logger.info("MCP Server connected to Redis")
    
    async def disconnect(self):
        """Disconnect from Redis"""
        if self.pubsub:
            await self.pubsub.close()
        if self.redis_client:
            await self.redis_client.close()
        logger.info("MCP Server disconnected")
    
    async def publish(self, channel: str, message: Dict[str, Any]) -> bool:
        """
        Publish a message to a channel
        
        Args:
            channel: Channel name
            message: Message data
        
        Returns:
            Success status
        """
        try:
            # Add timestamp if not present
            if 'timestamp' not in message:
                message['timestamp'] = datetime.now().isoformat()
            
            # Publish to channel
            message_json = json.dumps(message)
            await self.redis_client.publish(channel, message_json)
            
            # Store in stream for persistence
            stream_key = f"mcp:stream:{channel}"
            await self.redis_client.xadd(
                stream_key,
                message,
                maxlen=1000  # Keep last 1000 messages
            )
            
            logger.info(f"Published to {channel}: {message.get('event_type')}")
            
            # Broadcast to WebSocket clients
            await self._broadcast_to_websockets(channel, message)
            
            return True
        
        except Exception as e:
            logger.error(f"Error publishing to {channel}: {e}")
            return False
    
    async def subscribe(self, channel: str, callback: Callable = None):
        """
        Subscribe to a channel
        
        Args:
            channel: Channel name or pattern (supports wildcards)
            callback: Optional callback function for messages
        """
        try:
            # Use pattern subscribe for wildcards
            if '*' in channel:
                await self.pubsub.psubscribe(channel)
            else:
                await self.pubsub.subscribe(channel)
            
            if callback:
                if channel not in self.subscribers:
                    self.subscribers[channel] = []
                self.subscribers[channel].append(callback)
            
            logger.info(f"Subscribed to {channel}")
        
        except Exception as e:
            logger.error(f"Error subscribing to {channel}: {e}")
    
    async def listen(self):
        """Listen for messages on subscribed channels"""
        try:
            async for message in self.pubsub.listen():
                if message['type'] in ['message', 'pmessage']:
                    channel = message['channel']
                    data = json.loads(message['data'])
                    
                    logger.info(f"Received on {channel}: {data.get('event_type')}")
                    
                    # Call registered callbacks
                    if channel in self.subscribers:
                        for callback in self.subscribers[channel]:
                            try:
                                await callback(channel, data)
                            except Exception as e:
                                logger.error(f"Error in callback for {channel}: {e}")
        
        except Exception as e:
            logger.error(f"Error in listen loop: {e}")
    
    async def get_stream_messages(
        self, 
        channel: str, 
        count: int = 10,
        start_id: str = '-'
    ) -> List[Dict[str, Any]]:
        """
        Retrieve messages from a stream
        
        Args:
            channel: Channel name
            count: Number of messages to retrieve
            start_id: Starting message ID (- for beginning, + for new)
        
        Returns:
            List of messages
        """
        try:
            stream_key = f"mcp:stream:{channel}"
            messages = await self.redis_client.xrevrange(
                stream_key,
                max='+',
                min=start_id,
                count=count
            )
            
            result = []
            for msg_id, msg_data in messages:
                result.append({
                    'id': msg_id,
                    'data': msg_data
                })
            
            return result
        
        except Exception as e:
            logger.error(f"Error getting stream messages: {e}")
            return []
    
    async def _broadcast_to_websockets(self, channel: str, message: Dict[str, Any]):
        """Broadcast message to connected WebSocket clients"""
        if not self.active_websockets:
            return
        
        ws_message = {
            'channel': channel,
            'message': message
        }
        
        disconnected = []
        for ws in self.active_websockets:
            try:
                await ws.send_json(ws_message)
            except:
                disconnected.append(ws)
        
        # Remove disconnected clients
        for ws in disconnected:
            self.active_websockets.remove(ws)
    
    async def add_websocket(self, websocket: WebSocket):
        """Add a WebSocket connection"""
        await websocket.accept()
        self.active_websockets.append(websocket)
        logger.info(f"WebSocket connected. Total: {len(self.active_websockets)}")
    
    def remove_websocket(self, websocket: WebSocket):
        """Remove a WebSocket connection"""
        if websocket in self.active_websockets:
            self.active_websockets.remove(websocket)
            logger.info(f"WebSocket disconnected. Total: {len(self.active_websockets)}")


# FastAPI application for MCP Server
app = FastAPI(title="Planiva MCP Server")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global MCP instance
mcp = MCPServer()


@app.on_event("startup")
async def startup():
    """Startup event - connect to Redis"""
    await mcp.connect()
    
    # Subscribe to common channels
    await mcp.subscribe("tasks.*")
    await mcp.subscribe("crm.*")
    await mcp.subscribe("event.*")
    
    # Start listening in background
    asyncio.create_task(mcp.listen())


@app.on_event("shutdown")
async def shutdown():
    """Shutdown event - disconnect from Redis"""
    await mcp.disconnect()


@app.post("/publish/{channel}")
async def publish_message(channel: str, message: Dict[str, Any]):
    """
    Publish a message to MCP
    
    Args:
        channel: Channel name
        message: Message payload
    """
    success = await mcp.publish(channel, message)
    return {"success": success, "channel": channel}


@app.get("/messages/{channel}")
async def get_messages(channel: str, count: int = 10):
    """
    Get recent messages from a channel
    
    Args:
        channel: Channel name
        count: Number of messages to retrieve
    """
    messages = await mcp.get_stream_messages(channel, count)
    return {"channel": channel, "count": len(messages), "messages": messages}


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket endpoint for real-time message streaming"""
    await mcp.add_websocket(websocket)
    try:
        while True:
            # Keep connection alive and receive client messages if needed
            data = await websocket.receive_text()
            # Echo back or handle client commands
            await websocket.send_text(f"Received: {data}")
    except WebSocketDisconnect:
        mcp.remove_websocket(websocket)


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "mcp-server"}


if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("MCP_SERVER_PORT", 8001))
    uvicorn.run(app, host="0.0.0.0", port=port)