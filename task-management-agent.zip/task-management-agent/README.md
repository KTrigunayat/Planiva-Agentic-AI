# Planiva - Task Management Agent

This module implements the Task Management Agent for the Planiva Agentic Event Platform using CrewAI and MCP (Message Control Plane).

## Overview

The Task Management Agent consists of three specialized sub-agents:

1. **Task Maker Agent** - Converts event blueprints into actionable tasks
2. **Task Assigner Agent** - Assigns tasks to appropriate vendors/coordinators
3. **Task Updater Agent** - Monitors and updates task statuses

## Architecture

```
Task Management Agent
├── Task Maker (Blueprint → Tasks)
├── Task Assigner (Tasks → Vendors)
└── Task Updater (Monitor & Update)
    ↓
   MCP (Message Bus)
    ↓
CRM Agent (for outreach)
```

## Prerequisites

- Python 3.9+
- PostgreSQL 13+
- Redis 6+
- OpenAI API Key or Gemini API Key

## Installation

### 1. Clone and Setup

```bash
# Navigate to project directory
cd task-management-agent

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Environment Configuration

Create a `.env` file:

```bash
cp .env.example .env
```

Edit `.env` with your credentials:

```env
# Database
DATABASE_URL=postgresql://user:password@localhost:5432/planiva

# LLM API Keys
OPENAI_API_KEY=your_openai_key_here

# MCP Configuration
MCP_SERVER_HOST=localhost
MCP_SERVER_PORT=8001
REDIS_URL=redis://localhost:6379/0

# API Configuration
API_HOST=0.0.0.0
API_PORT=8000
```

### 3. Database Setup

```bash
# Start PostgreSQL and create database
createdb planiva

# Run migrations and seed data
python database/connection.py
```

### 4. Start Redis

```bash
# Using Docker
docker run -d -p 6379:6379 redis:latest

# Or using local Redis
redis-server
```

## Running the Application

### Start MCP Server (Terminal 1)

```bash
python mcp_server/server.py
```

This starts the Message Control Plane server on port 8001.

### Start FastAPI Application (Terminal 2)

```bash
python api/main.py
```

This starts the Task Management API on port 8000.

### Access API Documentation

Open browser: `http://localhost:8000/docs`

## Testing

### Run Individual Tool Tests

```bash
python tests/test_task_management.py tools
```

### Run Task Creation Test

```bash
python tests/test_task_management.py create
```

### Run Full Workflow Test

```bash
python tests/test_task_management.py full
```

## API Endpoints

### 1. Full Workflow

```bash
POST /workflow/full
```

Execute complete task management workflow:
- Create tasks from blueprint
- Assign tasks to vendors
- Setup monitoring

**Request Body:**
```json
{
  "blueprint": {
    "event_id": 1001,
    "plan_id": 5001,
    "event_title": "Conference 2025",
    "event_date": "2025-11-08T10:00:00",
    "milestones": [...]
  }
}
```

### 2. Create Tasks Only

```bash
POST /tasks/create
```

Create tasks from blueprint (Phase 1 only).

### 3. Assign Tasks Only

```bash
POST /tasks/assign/{event_id}/{plan_id}
```

Assign existing tasks to vendors (Phase 2 only).

### 4. Monitor Tasks

```bash
POST /tasks/monitor/{event_id}
```

Run monitoring for event tasks (Phase 3 only).

### 5. Get Tasks

```bash
GET /tasks/{event_id}?status=pending
```

Retrieve all tasks for an event, optionally filtered by status.

### 6. Get Task Detail

```bash
GET /tasks/detail/{task_id}
```

Get detailed information about a specific task.

### 7. Update Task Status

```bash
PUT /tasks/{task_id}/status
```

**Request Body:**
```json
{
  "task_id": 1,
  "event_id": 1001,
  "status": "completed",
  "updated_by": "coordinator",
  "reason": "Vendor confirmed completion"
}
```

## MCP Integration

### Publishing Events

The Task Management Agent publishes events to MCP:

- `task.created` - When a task is created
- `task.assigned` - When a task is assigned (triggers CRM)
- `task.status_updated` - When task status changes

### Subscribing to Events

The Task Updater Agent subscribes to:

- `crm.vendor_confirmed` - Vendor acknowledged task
- `crm.vendor_started` - Vendor started work
- `crm.vendor_completed` - Vendor completed task
- `crm.vendor_issue` - Vendor reported problem

### MCP Channels

- `event.{event_id}.tasks` - Task events for specific event
- `crm.outreach.{event_id}` - CRM outreach channel
- `tasks.alerts` - Critical task alerts

## Project Structure

```
task-management-agent/
├── src/
│   ├── agents/              # Agent implementations
│   │   ├── task_maker_agent.py
│   │   ├── task_assigner_agent.py
│   │   └── task_updater_agent.py
│   ├── crews/               # CrewAI orchestration
│   │   └── task_management_crew.py
│   ├── tools/               # CrewAI tools
│   │   ├── database_tools.py
│   │   └── mcp_tools.py
│   ├── models/              # Pydantic schemas
│   │   └── schemas.py
│   └── config/              # YAML configurations
│       ├── agents.yaml
│       └── tasks.yaml
├── mcp_server/              # MCP server
│   └── server.py
├── database/                # Database setup
│   ├── connection.py
│   └── migrations.sql
├── api/                     # FastAPI application
│   └── main.py
├── tests/                   # Test suite
│   └── test_task_management.py
├── requirements.txt
├── .env.example
└── README.md
```

## Integration with Other Agents

### 1. Event Planning Agent (Input)

Receives `EventBlueprint` with milestones from the Event Planning Agent.

### 2. CRM Agent (Output)

Publishes `task.assigned` events that trigger the CRM Agent to:
- Send emails to vendors
- Make automated calls
- Send SMS reminders
- Follow up on confirmations

### 3. Main Orchestrator

Integrates with Main Planiva orchestrator for end-to-end event automation.

## Key Features

### Intelligent Task Assignment

- Vendor suitability scoring based on:
  - Service match
  - Vendor ratings
  - Current workload
  - Past performance
  - Task priority

### Dependency Management

- Automatic dependency resolution
- Blocked task detection
- Critical path analysis

### Real-time Monitoring

- Deadline tracking
- Status updates from CRM
- Automatic escalations
- Progress reporting

### MCP Event Bus

- Asynchronous inter-agent communication
- Reliable message delivery with Redis Streams
- WebSocket support for real-time updates

## Troubleshooting

### Database Connection Issues

```bash
# Check PostgreSQL is running
pg_isready

# Test connection
psql -U user -d planiva -c "SELECT 1"
```

### Redis Connection Issues

```bash
# Test Redis connection
redis-cli ping

# Should return: PONG
```

### Agent Execution Issues

Check logs for detailed error messages. Enable verbose mode in agent configs:

```yaml
verbose: true
```

## Development Tips

### Adding New Tools

1. Create tool class in `src/tools/`
2. Inherit from `BaseTool`
3. Define `args_schema` using Pydantic
4. Implement `_run()` method
5. Add to agent's tool list

### Modifying Agent Behavior

Edit configurations in:
- `src/config/agents.yaml` - Agent roles and goals
- `src/config/tasks.yaml` - Task descriptions

### Testing New Features

Add test cases in `tests/test_task_management.py`

## Next Steps

1. **Integration Testing** - Test with Event Planning Agent output
2. **CRM Integration** - Connect with CRM Agent
3. **Dashboard UI** - Build monitoring dashboard
4. **Performance Optimization** - Optimize for large events
5. **Advanced Features**:
   - Dynamic task reassignment
   - Predictive delay detection
   - Automated contingency activation

## License

Part of Planiva - TIE Bangalore Pitch Project

## Contributors

[Your Team Name]