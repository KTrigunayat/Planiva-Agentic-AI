"""
FastAPI application for Task Management Agent
Provides REST endpoints to trigger agent workflows
"""
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, Dict, Any
import os
from datetime import datetime
from dotenv import load_dotenv

# Load .env file at the start
load_dotenv()

# FIX: Re-added 'src.' prefix to all imports
from src.crews.task_management_crew import TaskManagementCrew
from src.models.schemas import EventBlueprint, TaskStatusUpdate, TaskAssignmentRequest
from src.tools.database_tools import GetTasksTool, UpdateTaskTool
from src.tools.mcp_tools import PublishTaskStatusUpdateTool

# Initialize FastAPI
app = FastAPI(
    title="Planiva Task Management API",
    description="API for Task Management Agent with CrewAI",
    version="1.0.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global crew instance
task_crew = TaskManagementCrew()

# Request/Response Models
class BlueprintInput(BaseModel):
    blueprint: EventBlueprint

class WorkflowResponse(BaseModel):
    success: bool
    message: str
    event_id: int
    plan_id: int
    workflow_id: Optional[str] = None

class TaskListResponse(BaseModel):
    success: bool
    count: int
    tasks: list

# Endpoints
@app.get("/")
async def root():
    """Root endpoint"""
    return {"message": "Planiva Task Management API is running"}

@app.post("/workflow/run", response_model=WorkflowResponse)
async def run_full_workflow(data: BlueprintInput, background_tasks: BackgroundTasks):
    """
    Run the full task management workflow from blueprint to assignment
    """
    try:
        event_id = data.blueprint.event_id
        plan_id = data.blueprint.plan_id
        
        background_tasks.add_task(task_crew.run_full_workflow, data.blueprint.dict())
        
        return {
            "success": True,
            "message": "Task management workflow started in the background",
            "event_id": event_id,
            "plan_id": plan_id
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/tasks/{event_id}", response_model=TaskListResponse)
async def get_tasks_for_event(event_id: int):
    """
    Get all tasks associated with a specific event
    """
    try:
        get_tool = GetTasksTool()
        result_str = get_tool._run(event_id=event_id)
        result = eval(result_str)
        
        if not result['success']:
            raise HTTPException(status_code=500, detail=result.get('error'))
            
        return {
            "success": True,
            "count": len(result['tasks']),
            "tasks": result['tasks']
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.patch("/tasks/{task_id}/status")
async def update_task_status(task_id: int, update: TaskStatusUpdate):
    """
    Manually update the status of a task
    """
    try:
        update_tool = UpdateTaskTool()
        result_str = update_tool._run(
            task_id=task_id,
            status=update.status.value,
            changed_by=update.updated_by,
            notes=update.reason,
            actual_duration_minutes=update.actual_duration_minutes
        )
        result = eval(result_str)
        
        if not result['success']:
            raise HTTPException(status_code=500, detail=result.get('error'))
        
        return {
            "success": True,
            "message": "Task status updated",
            "task_id": task_id,
            "new_status": update.status.value
        }
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "task-management-api"
    }