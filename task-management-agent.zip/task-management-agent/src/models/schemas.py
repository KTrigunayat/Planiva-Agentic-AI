from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime
from enum import Enum


class OwnerType(str, Enum):
    VENDOR = "vendor"
    INTERNAL = "internal"
    COORDINATOR = "coordinator"


class TaskStatus(str, Enum):
    PENDING = "pending"
    ASSIGNED = "assigned"
    IN_PROGRESS = "in_progress"
    BLOCKED = "blocked"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class TaskPriority(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class DependencyType(str, Enum):
    FINISH_TO_START = "finish_to_start"
    START_TO_START = "start_to_start"
    FINISH_TO_FINISH = "finish_to_finish"


class TaskDependency(BaseModel):
    task_id: int
    depends_on_task_id: int
    dependency_type: DependencyType = DependencyType.FINISH_TO_START


class TaskBase(BaseModel):
    title: str
    description: Optional[str] = None
    owner_type: OwnerType
    owner_id: Optional[int] = None
    owner_name: Optional[str] = None
    owner_contact: Optional[str] = None
    due_date: datetime
    priority: TaskPriority = TaskPriority.MEDIUM
    acceptance_criteria: Optional[str] = None
    estimated_duration_minutes: Optional[int] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class TaskCreate(TaskBase):
    plan_id: int
    event_id: int
    dependencies: List[int] = Field(default_factory=list)


class TaskUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    status: Optional[TaskStatus] = None
    owner_type: Optional[OwnerType] = None
    owner_id: Optional[int] = None
    owner_name: Optional[str] = None
    owner_contact: Optional[str] = None
    due_date: Optional[datetime] = None
    priority: Optional[TaskPriority] = None
    acceptance_criteria: Optional[str] = None
    actual_duration_minutes: Optional[int] = None
    notes: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class Task(TaskBase):
    id: int
    plan_id: int
    event_id: int
    assigned_by: Optional[str] = None
    status: TaskStatus
    dependencies: List[int] = Field(default_factory=list)
    actual_duration_minutes: Optional[int] = None
    created_at: datetime
    updated_at: datetime
    completed_at: Optional[datetime] = None
    notes: Optional[str] = None

    class Config:
        from_attributes = True


class BlueprintMilestone(BaseModel):
    """Input from Event Planning Agent's Timeline/Blueprint"""
    milestone_name: str
    description: str
    start_time: datetime
    end_time: datetime
    duration_minutes: int
    responsible_party: str  # vendor name or internal team
    dependencies: List[str] = Field(default_factory=list)  # milestone names
    deliverables: List[str] = Field(default_factory=list)
    vendor_id: Optional[int] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class EventBlueprint(BaseModel):
    """Complete blueprint from Event Planning Agent"""
    event_id: int
    plan_id: int
    event_title: str
    event_date: datetime
    milestones: List[BlueprintMilestone]
    vendors: List[Dict[str, Any]]  # vendor details
    budget_allocation: Dict[str, float]
    metadata: Dict[str, Any] = Field(default_factory=dict)


class TaskAssignmentRequest(BaseModel):
    task_id: int
    owner_type: OwnerType
    owner_id: Optional[int] = None
    owner_name: str
    owner_contact: str
    assigned_by: str
    reason: Optional[str] = None


class TaskStatusUpdate(BaseModel):
    task_id: int
    status: TaskStatus
    updated_by: str
    reason: Optional[str] = None
    actual_duration_minutes: Optional[int] = None
    notes: Optional[str] = None


class MCPTaskMessage(BaseModel):
    """MCP message format for task-related events"""
    event_type: str  # task.created, task.assigned, task.updated, task.completed
    task_id: int
    event_id: int
    plan_id: int
    timestamp: datetime
    payload: Dict[str, Any]
    source_agent: str = "task_management"