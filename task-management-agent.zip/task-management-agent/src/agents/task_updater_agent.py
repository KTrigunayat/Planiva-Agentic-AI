from crewai import Agent
from typing import List, Dict, Set
import yaml
import os
from datetime import datetime, timedelta


# FIX 1: Add 'llm' to the function definition
def create_task_updater_agent(tools: List, llm) -> Agent:
    """
    Creates the Task Updater Agent responsible for monitoring and updating task statuses
    
    Args:
        tools: List of CrewAI tools (GetTasksTool, UpdateTaskTool, 
               PublishTaskStatusUpdateTool, SubscribeToEventsTool)
        llm: The language model instance to be used by the agent
    
    Returns:
        Agent: Configured CrewAI Agent
    """
    # Load agent config
    config_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'agents.yaml')
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    
    agent_config = config['task_updater_agent']
    
    agent = Agent(
        role=agent_config['role'],
        goal=agent_config['goal'],
        backstory=agent_config['backstory'],
        tools=tools,
        llm=llm,  # <-- FIX 2: Pass the llm to the agent
        verbose=agent_config['verbose'],
        allow_delegation=agent_config['allow_delegation'],
        max_iter=25,
        memory=True
    )
    
    return agent


# Helper functions for task monitoring
def check_task_deadlines(tasks: List[Dict], warning_hours: int = 24) -> Dict:
    """
    Check tasks against their deadlines
    
    Args:
        tasks: List of task dictionaries
        warning_hours: Number of hours before deadline to issue a warning
    
    Returns:
        Dictionary with lists of overdue tasks and at-risk tasks
    """
    now = datetime.now()
    overdue = []
    at_risk = []
    
    warning_delta = timedelta(hours=warning_hours)
    
    for task in tasks:
        if task.get('status') not in ['completed', 'cancelled']:
            due_date_str = task.get('due_date')
            if due_date_str:
                due_date = datetime.fromisoformat(due_date_str.replace('Z', '+00:00')).replace(tzinfo=None)
                
                if now > due_date:
                    overdue.append(task)
                elif (due_date - now) <= warning_delta:
                    at_risk.append(task)
                    
    return {'overdue_tasks': overdue, 'at_risk_tasks': at_risk}


def find_blocked_tasks(tasks: List[Dict]) -> List[Dict]:
    """
    Find tasks with status 'blocked'
    """
    return [task for task in tasks if task.get('status') == 'blocked']


def analyze_dependencies(tasks: List[Dict]) -> Dict:
    """
    Analyze dependencies to find at-risk chains
    """
    task_map = {task['id']: task for task in tasks}
    at_risk_chains = []
    
    for task in tasks:
        if task.get('status') not in ['completed', 'cancelled']:
            dependencies = task.get('dependencies', [])
            for dep_id in dependencies:
                dep_task = task_map.get(dep_id)
                if dep_task and dep_task.get('status') == 'blocked':
                    at_risk_chains.append({
                        'task': task,
                        'blocking_task_id': dep_id,
                        'blocker_status': 'blocked'
                    })
                elif dep_task and dep_task.get('status') != 'completed':
                    # Could add more complex logic for at-risk (e.g., overdue dependency)
                    pass
    
    return {'at_risk_chains': at_risk_chains}


def generate_escalation_report(
    overdue_tasks: List[Dict],
    blocked_tasks: List[Dict],
    at_risk_chains: List[Dict]
) -> List[Dict]:
    """
    Generate a report of escalations for high-priority issues
    """
    escalations = []
    
    # Overdue critical/high priority tasks
    for task in overdue_tasks:
        if task.get('priority') in ['critical', 'high']:
            escalations.append({
                'task_id': task.get('id'),
                'task_title': task.get('title'),
                'severity': 'high',
                'reason': 'Critical task is overdue',
                'recommendation': 'Immediate coordinator intervention required. Consider reassignment or expedited vendor engagement.',
                'action': 'escalate_to_coordinator'
            })
    
    # Blocked tasks
    for task in blocked_tasks:
        escalations.append({
            'task_id': task.get('id'),
            'task_title': task.get('title'),
            'severity': 'medium',
            'reason': f"Task blocked: {task.get('notes', 'Unknown reason')}",
            'recommendation': 'Identify and resolve blocker. May need alternate vendor or resource reallocation.',
            'action': 'investigate_blocker'
        })
    
    # At-risk dependency chains
    for chain_info in at_risk_chains:
        task = chain_info['task']
        escalations.append({
            'task_id': task.get('id'),
            'task_title': task.get('title'),
            'severity': 'medium',
            'reason': 'Dependent task is blocked, affecting this task',
            'recommendation': 'Monitor dependency resolution. Prepare contingency if blocker persists.',
            'action': 'monitor_dependency'
        })
    
    return escalations