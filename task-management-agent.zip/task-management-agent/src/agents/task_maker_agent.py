from crewai import Agent
from typing import List
import yaml
import os


# FIX 1: Add 'llm' to the function definition
def create_task_maker_agent(tools: List, llm) -> Agent:
    """
    Creates the Task Maker Agent responsible for converting blueprints to tasks
    
    Args:
        tools: List of CrewAI tools (CreateTaskTool, GetTasksTool, PublishTaskCreatedTool)
        llm: The language model instance to be used by the agent
    
    Returns:
        Agent: Configured CrewAI Agent
    """
    # Load agent config
    config_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'agents.yaml')
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    
    agent_config = config['task_maker_agent']
    
    agent = Agent(
        role=agent_config['role'],
        goal=agent_config['goal'],
        backstory=agent_config['backstory'],
        tools=tools,
        llm=llm,  # <-- FIX 2: Pass the llm to the agent
        verbose=agent_config['verbose'],
        allow_delegation=agent_config['allow_delegation'],
        max_iter=15,  # Maximum iterations for task execution
        memory=True   # Enable memory for context retention
    )
    
    return agent


# Helper function to parse blueprint and create task list
def parse_blueprint_to_task_specs(blueprint: dict) -> List[dict]:
    """
    Helper function to convert blueprint structure into task specifications
    
    Args:
        blueprint: Event blueprint dictionary
    
    Returns:
        List of task specification dictionaries
    """
    task_specs = []
    milestones = blueprint.get('milestones', [])
    vendors = {v['id']: v for v in blueprint.get('vendors', [])}
    
    milestone_to_task_id = {}
    
    for idx, milestone in enumerate(milestones):
        responsible_party = milestone.get('responsible_party')
        vendor_id = milestone.get('vendor_id')
        
        owner_type = 'vendor' if vendor_id else 'internal'
        
        start_time = milestone.get('start_time')
        end_time = milestone.get('end_time')
        duration_minutes = milestone.get('duration_minutes')
        
        deliverables = milestone.get('deliverables', [])
        acceptance_criteria = "Completion of the following deliverables:\n" + "\n".join(f"- {d}" for d in deliverables)
        
        # Determine priority
        if any(keyword in milestone.get('milestone_name', '').lower() for keyword in ['main event', 'keynote', 'registration']):
            priority = 'critical'
        elif any(keyword in milestone.get('milestone_name', '').lower() for keyword in ['setup', 'teardown', 'preparation', 'arrival']):
            priority = 'high'
        else:
            priority = 'medium'
        
        task_spec = {
            'title': milestone.get('milestone_name'),
            'description': milestone.get('description'),
            'owner_type': owner_type,
            'owner_name': responsible_party if responsible_party else None,
            'vendor_id': vendor_id,
            'due_date': end_time,  # Task should be done by milestone end
            'priority': priority,
            'acceptance_criteria': acceptance_criteria,
            'estimated_duration_minutes': duration_minutes,
            'milestone_dependencies': milestone.get('dependencies', []),
            'metadata': {
                'milestone_name': milestone.get('milestone_name'),
                'milestone_start': start_time,
                'milestone_end': end_time,
                'sub_event': milestone.get('metadata', {}).get('sub_event', '')
            }
        }
        
        task_specs.append(task_spec)
        milestone_to_task_id[milestone.get('milestone_name')] = idx
    
    # Resolve dependencies (milestone names to task indices)
    for task_spec in task_specs:
        dep_names = task_spec.pop('milestone_dependencies', [])
        task_spec['dependencies'] = [
            milestone_to_task_id[dep_name] 
            for dep_name in dep_names if dep_name in milestone_to_task_id
        ]
    return task_specs