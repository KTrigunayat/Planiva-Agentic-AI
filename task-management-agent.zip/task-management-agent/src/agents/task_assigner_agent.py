from crewai import Agent
from typing import List, Dict, Optional
import yaml
import os
import json


# FIX 1: Add 'llm' to the function definition
def create_task_assigner_agent(tools: List, llm) -> Agent:
    """
    Creates the Task Assigner Agent responsible for assigning tasks to vendors/coordinators
    
    Args:
        tools: List of CrewAI tools (GetTasksTool, GetVendorInfoTool, UpdateTaskTool, PublishTaskAssignedTool)
        llm: The language model instance to be used by the agent
    
    Returns:
        Agent: Configured CrewAI Agent
    """
    # Load agent config
    config_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'agents.yaml')
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    
    agent_config = config['task_assigner_agent']
    
    agent = Agent(
        role=agent_config['role'],
        goal=agent_config['goal'],
        backstory=agent_config['backstory'],
        tools=tools,
        llm=llm,  # <-- FIX 2: Pass the llm to the agent
        verbose=agent_config['verbose'],
        allow_delegation=agent_config['allow_delegation'],
        max_iter=20,
        memory=True
    )
    
    return agent


# Helper functions for assignment logic
def calculate_vendor_suitability_score(
    vendor: Dict,
    task: Dict,
    current_workload: int = 0
) -> float:
    """
    Calculate a suitability score for a vendor for a given task
    
    Args:
        vendor: Vendor dict
        task: Task dict
        current_workload: Number of tasks already assigned to vendor
    
    Returns:
        Suitability score (0-100)
    """
    score = 0
    
    # Service match (very important)
    task_services = task.get('metadata', {}).get('required_services', [])
    vendor_services = vendor.get('services', [])
    if any(s in vendor_services for s in task_services):
        score += 50
    
    # Rating bonus
    rating = vendor.get('rating', 0) or 0
    if rating > 4.5:
        score += 20
    elif rating > 4.0:
        score += 10
        
    # Capacity check
    capacity = vendor.get('capacity')
    if capacity and capacity > 0: # simplified check
        score += 15
        
    # Workload penalty (heavy penalty for overloaded vendors)
    workload_penalty = current_workload * 15
    score -= workload_penalty
    
    # Priority boost
    if task.get('priority') == 'critical':
        score *= 1.1
    
    return max(0, score) # Ensure score is not negative


def find_best_vendor_for_task(
    task: Dict,
    available_vendors: List[Dict],
    workload_distribution: Dict
) -> Optional[Dict]:
    """
    Find the best vendor for a task based on suitability score
    
    Args:
        task: Task dict
        available_vendors: List of available vendors
        workload_distribution: Dict of current workload per vendor
    
    Returns:
        Best vendor dict or None
    """
    if not available_vendors:
        return None
    
    vendor_scores = []
    
    for vendor in available_vendors:
        vendor_id = vendor.get('id')
        workload_key = f"vendor_{vendor_id}"
        current_workload = workload_distribution.get(workload_key, 0)
        
        score = calculate_vendor_suitability_score(vendor, task, current_workload)
        vendor_scores.append({
            'vendor': vendor,
            'score': score,
            'workload': current_workload
        })
    
    # Sort by score (descending)
    vendor_scores.sort(key=lambda x: x['score'], reverse=True)
    
    # Return best vendor if score is reasonable (>40)
    if vendor_scores and vendor_scores[0]['score'] > 40:
        return vendor_scores[0]['vendor']
    
    return None


def should_assign_to_internal(task: Dict) -> bool:
    """
    Determine if a task should be assigned to internal coordinator
    
    Args:
        task: Task dict
    
    Returns:
        True if should be internal
    """
    # Check owner_type from task creation
    if task.get('owner_type') == 'internal':
        return True
    
    # Check if it's a coordination/management task
    title_lower = task.get('title', '').lower()
    if any(keyword in title_lower for keyword in ['coordinate', 'manage', 'oversee', 'confirm']):
        return True
        
    return False