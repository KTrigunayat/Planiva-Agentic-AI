from crewai import Crew, Task, Process
from typing import Dict, Any
import yaml
import os
from langchain_groq import ChatGroq
from dotenv import load_dotenv
import json
from datetime import datetime, date
import time

load_dotenv()

from src.agents.task_maker_agent import create_task_maker_agent
from src.agents.task_assigner_agent import create_task_assigner_agent
from src.agents.task_updater_agent import create_task_updater_agent
from src.tools.database_tools import (
    CreateTaskTool, GetTasksTool, UpdateTaskTool, GetVendorInfoTool
)
from src.tools.mcp_tools import (
    PublishTaskCreatedTool, PublishTaskAssignedTool,
    PublishTaskStatusUpdateTool, SubscribeToEventsTool
)


class TaskManagementCrew:
    """
    Main Crew for Task Management Agent System
    Orchestrates three sub-agents: Task Maker, Task Assigner, Task Updater
    """
    
    def __init__(self):
        """Initialize the Task Management Crew with all agents and tools"""
        
        # CORRECTED: Using groq/ prefix with optimized settings for rate limits
        self.groq_llm = ChatGroq(
            api_key=os.getenv("GROQ_API_KEY"),
            model_name="groq/llama-3.3-70b-versatile",
            temperature=0,  # Reduced for more deterministic, shorter responses
            max_tokens=2048,  # Reduced from 4096 to save tokens
            timeout=60,
            max_retries=3
        )
        
        # Smaller, faster model for simpler tasks (task assignment/updates)
        self.groq_llm_small = ChatGroq(
            api_key=os.getenv("GROQ_API_KEY"),
            model_name="groq/llama-3.1-8b-instant",
            temperature=0,
            max_tokens=1024,
            timeout=30,
            max_retries=3
        )
        
        self.db_tools = {
            'create_task': CreateTaskTool(),
            'get_tasks': GetTasksTool(),
            'update_task': UpdateTaskTool(),
            'get_vendor_info': GetVendorInfoTool()
        }
        
        self.mcp_tools = {
            'publish_created': PublishTaskCreatedTool(),
            'publish_assigned': PublishTaskAssignedTool(),
            'publish_status': PublishTaskStatusUpdateTool(),
            'subscribe': SubscribeToEventsTool()
        }

        # Use 70B for complex task creation, 8B for simpler assignment/monitoring
        self.task_maker = create_task_maker_agent(
            tools=list(self.db_tools.values()),
            llm=self.groq_llm  # 70B for complex reasoning
        )
        
        self.task_assigner = create_task_assigner_agent(
            tools=list(self.db_tools.values()),
            llm=self.groq_llm_small  # 8B is sufficient for assignment
        )
        
        self.task_updater = create_task_updater_agent(
            tools=list(self.db_tools.values()),
            llm=self.groq_llm_small  # 8B is sufficient for updates
        )
    
    def define_tasks(self, blueprint: Dict[str, Any]) -> tuple[Task, Task, Task]:
        """
        Define the three sequential tasks for the workflow
        """
        config_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'tasks.yaml')
        with open(config_path, 'r') as f:
            tasks_config = yaml.safe_load(f)
            
        task_creation = Task(
            **tasks_config['create_tasks_from_blueprint'],
            agent=self.task_maker
        )
        
        task_assignment = Task(
            **tasks_config['assign_tasks_to_owners'],
            agent=self.task_assigner,
            context=[task_creation]
        )
        
        task_monitoring = Task(
            **tasks_config['monitor_and_update_tasks'],
            agent=self.task_updater,
            context=[task_creation, task_assignment]
        )
        
        return (task_creation, task_assignment, task_monitoring)

    def run_full_workflow(self, blueprint: Dict[str, Any]) -> Dict[str, Any]:
        """
        Run the full task management workflow with retry logic for rate limits
        """
        max_retries = 3
        retry_delay = 60  # Increased to 60 seconds to let rate limits fully reset
        
        for attempt in range(max_retries):
            try:
                task_creation, task_assignment, task_monitoring = self.define_tasks(blueprint)
                
                crew = Crew(
                    agents=[self.task_maker, self.task_assigner, self.task_updater],
                    tasks=[task_creation, task_assignment, task_monitoring],
                    process=Process.sequential,
                    verbose=True,
                    manager_llm=self.groq_llm  # Ensure crew uses the same LLM
                )
                
                def json_converter(o):
                    if isinstance(o, (datetime, date)):
                        return o.isoformat()

                blueprint_str = json.dumps(blueprint, default=json_converter)
                safe_blueprint = json.loads(blueprint_str)

                result = crew.kickoff(inputs={'blueprint': safe_blueprint})
                
                return {
                    'success': True,
                    'event_id': blueprint.get('event_id'),
                    'result': result
                }
                
            except Exception as e:
                error_msg = str(e)
                
                # Check if it's a rate limit error
                if "rate_limit" in error_msg.lower() or "rate limit" in error_msg.lower():
                    if attempt < max_retries - 1:
                        print(f"\n⚠️  Rate limit hit. Waiting {retry_delay} seconds before retry {attempt + 2}/{max_retries}...")
                        time.sleep(retry_delay)
                        continue
                    else:
                        return {
                            'success': False,
                            'error': 'Rate limit exceeded after multiple retries',
                            'details': error_msg,
                            'suggestion': 'Please wait a few minutes before trying again'
                        }
                
                # For other errors, raise immediately
                raise

    def run_assignment_only(self, event_id: int, plan_id: int) -> Dict[str, Any]:
        pass

    def run_monitoring_only(self, event_id: int) -> Dict[str, Any]:
        pass