from crewai.tools import BaseTool
from typing import Type, List, Optional, Dict, Any
from pydantic import BaseModel, Field
import psycopg2
from psycopg2.extras import RealDictCursor
import json
from datetime import datetime
import os


class TaskDatabaseTool(BaseTool):
    name: str = "Task Database Tool"
    description: str = "A tool to interact with the tasks database."

    def _get_connection(self):
        connection_string = os.getenv("DATABASE_URL")
        return psycopg2.connect(connection_string)


class CreateTaskInput(BaseModel):
    plan_id: int = Field(..., description="The ID of the event plan.")
    event_id: int = Field(..., description="The main ID for the event.")
    title: str = Field(..., description="The title of the task.")
    description: str = Field(..., description="A detailed description of the task.")
    owner_type: str = Field(..., description="Type of owner, e.g., 'vendor' or 'internal'.")
    due_date: str = Field(..., description="The date and time the task is due. Must be in ISO 8601 format.")
    priority: str = Field("medium", description="Priority of the task (e.g., 'medium', 'high').")
    acceptance_criteria: Optional[str] = Field(None, description="Criteria for task completion.")
    estimated_duration_minutes: Optional[int] = Field(None, description="Estimated time in minutes to complete the task.")
    dependencies: List[int] = Field(default_factory=list, description="A list of other task IDs that this task depends on.")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Any other relevant data in a JSON object.")


class CreateTaskTool(TaskDatabaseTool):
    name: str = "Create Task Tool"
    description: str = "Use this tool to create a brand new task in the database. You must provide all required details for the task."
    args_schema: Type[BaseModel] = CreateTaskInput

    def _run(self, **kwargs) -> str:
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            due_date_obj = datetime.fromisoformat(kwargs['due_date'].replace('Z', '+00:00'))
            
            query = """
                INSERT INTO tasks (plan_id, event_id, title, description, owner_type, due_date, priority, 
                                   acceptance_criteria, estimated_duration_minutes, dependencies, metadata)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING id;
            """
            
            cursor.execute(query, (
                kwargs['plan_id'], kwargs['event_id'], kwargs['title'], kwargs['description'], kwargs['owner_type'], due_date_obj,
                kwargs.get('priority', 'medium'), kwargs.get('acceptance_criteria'),
                kwargs.get('estimated_duration_minutes'), json.dumps(kwargs.get('dependencies', [])),
                json.dumps(kwargs.get('metadata', {}))
            ))
            
            task_id = cursor.fetchone()[0]
            conn.commit()
            cursor.close()
            conn.close()
            
            return json.dumps({"success": True, "task_id": task_id, "message": f"Task '{kwargs['title']}' created successfully with ID {task_id}."})
        except Exception as e:
            return json.dumps({"success": False, "error": str(e)})


class GetTasksInput(BaseModel):
    event_id: int = Field(..., description="The main ID for the event whose tasks you want to retrieve.")

class GetTasksTool(TaskDatabaseTool):
    name: str = "Get Tasks Tool"
    description: str = "Use this tool to get a list of all tasks for a specific event ID."
    args_schema: Type[BaseModel] = GetTasksInput

    def _run(self, event_id: int) -> str:
        try:
            conn = self._get_connection()
            cursor = conn.cursor(cursor_factory=RealDictCursor)
            
            query = "SELECT * FROM tasks WHERE event_id = %s"
            cursor.execute(query, (event_id,))
            tasks = cursor.fetchall()
            cursor.close()
            conn.close()
            
            for task in tasks:
                for key, value in task.items():
                    if isinstance(value, datetime):
                        task[key] = value.isoformat()

            return json.dumps({"success": True, "tasks": tasks})
        except Exception as e:
            return json.dumps({"success": False, "error": str(e)})


class UpdateTaskInput(BaseModel):
    task_id: int = Field(..., description="The ID of the task you need to update. This is a mandatory field.")
    status: Optional[str] = Field(None, description="The new status for the task (e.g., 'assigned', 'in_progress').")
    owner_id: Optional[int] = Field(None, description="The ID of the assigned vendor or internal owner.")
    owner_name: Optional[str] = Field(None, description="The name of the assigned owner.")
    owner_contact: Optional[str] = Field(None, description="The contact information for the assigned owner.")
    notes: Optional[str] = Field(None, description="Additional notes or comments about the update.")
    changed_by: str = Field("System", description="The name of the agent or system making the change.")


class UpdateTaskTool(TaskDatabaseTool):
    name: str = "Update Task Tool"
    description: str = "Use this tool to update an existing task, for example, to assign an owner or change its status. You MUST provide a task_id."
    args_schema: Type[BaseModel] = UpdateTaskInput

    def _run(self, task_id: int, **kwargs) -> str:
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            update_fields = []
            params = []
            
            for key, value in kwargs.items():
                if value is not None and key != 'task_id':
                    update_fields.append(f"{key} = %s")
                    params.append(value)
            
            if not update_fields:
                return json.dumps({"success": False, "error": "No fields to update"})
            
            params.append(task_id)
            query = f"UPDATE tasks SET {', '.join(update_fields)}, updated_at = NOW() WHERE id = %s RETURNING id;"
            
            cursor.execute(query, params)
            updated_id = cursor.fetchone()
            
            if updated_id is None:
                return json.dumps({"success": False, "error": f"Task with ID {task_id} not found"})

            conn.commit()
            cursor.close()
            conn.close()
            
            return json.dumps({"success": True, "task_id": updated_id[0], "message": f"Task {task_id} updated successfully"})
        except Exception as e:
            return json.dumps({"success": False, "error": str(e)})


class GetVendorInfoInput(BaseModel):
    service_type: str = Field(..., description="The type of service required (e.g., 'venue', 'catering') to find suitable vendors.")

class GetVendorInfoTool(TaskDatabaseTool):
    name: str = "Get Vendor Info Tool"
    description: str = "Use this tool to find vendors that provide a specific type of service."
    args_schema: Type[BaseModel] = GetVendorInfoInput

    def _run(self, service_type: str) -> str:
        try:
            conn = self._get_connection()
            cursor = conn.cursor(cursor_factory=RealDictCursor)
            
            query = "SELECT id, name, services, contact_info FROM vendors WHERE %s = ANY(services)"
            cursor.execute(query, (service_type,))
            vendors = cursor.fetchall()
            cursor.close()
            conn.close()
            
            return json.dumps({"success": True, "vendors": vendors})
        except Exception as e:
            return json.dumps({"success": False, "error": str(e)})