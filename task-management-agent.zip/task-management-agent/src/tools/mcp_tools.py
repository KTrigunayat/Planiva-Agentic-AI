from crewai.tools import BaseTool
from typing import Type, Dict, Any
from pydantic import BaseModel, Field
import redis
import json
from datetime import datetime
import os


class MCPPublisher(BaseTool):
    name: str = "MCP Publisher"
    description: str = "Publish task events to MCP message bus for other agents"
    
    # --- THE FIX IS HERE ---
    # We removed the __init__ method.
    # This helper function now creates the Redis client on-demand.
    def _get_redis_client(self):
        """Creates and returns a Redis client, or None if connection fails."""
        redis_url = os.getenv("REDIS_URL", "redis://localhost:6379/0")
        try:
            client = redis.from_url(redis_url, decode_responses=True)
            client.ping()
            return client
        except redis.exceptions.ConnectionError:
            print("--- WARNING: Redis not connected. MCP tools will be disabled. ---")
            return None

    def _publish_event(self, channel: str, message: Dict[str, Any]) -> bool:
        """Publish message to Redis channel"""
        redis_client = self._get_redis_client()
        if not redis_client:
            return True # Pretend to succeed if Redis is offline
            
        try:
            message['timestamp'] = datetime.now().isoformat()
            redis_client.publish(channel, json.dumps(message))
            
            stream_key = f"mcp:stream:{channel}"
            redis_client.xadd(stream_key, message, maxlen=1000)
            
            return True
        except Exception as e:
            print(f"Error publishing to MCP: {e}")
            return False


class PublishTaskCreatedInput(BaseModel):
    task_id: int
    event_id: int
    plan_id: int
    title: str
    owner_type: str
    due_date: str

class PublishTaskCreatedTool(MCPPublisher):
    name: str = "Publish Task Created Event"
    description: str = "Publish an event to MCP when a new task is created"
    args_schema: Type[BaseModel] = PublishTaskCreatedInput

    def _run(self, **kwargs) -> str:
        """Publish task created event"""
        success = self._publish_event(
            channel=f"event:{kwargs['event_id']}:task_created",
            message=kwargs
        )
        return json.dumps({
            "success": success,
            "message": f"Published creation event for task {kwargs['task_id']}"
        })


class PublishTaskAssignedInput(BaseModel):
    task_id: int
    event_id: int
    owner_type: str
    owner_id: int
    owner_name: str
    assigned_by: str

class PublishTaskAssignedTool(MCPPublisher):
    name: str = "Publish Task Assigned Event"
    description: str = "Publish an event to MCP when a task is assigned"
    args_schema: Type[BaseModel] = PublishTaskAssignedInput
    
    def _run(self, **kwargs) -> str:
        """Publish task assigned event"""
        success = self._publish_event(
            channel=f"event:{kwargs['event_id']}:task_assigned",
            message=kwargs
        )
        return json.dumps({
            "success": success,
            "message": f"Published assignment event for task {kwargs['task_id']}"
        })


class PublishTaskStatusUpdateInput(BaseModel):
    task_id: int
    event_id: int
    old_status: str
    new_status: str
    updated_by: str
    reason: str

class PublishTaskStatusUpdateTool(MCPPublisher):
    name: str = "Publish Task Status Update Event"
    description: str = "Publish an event to MCP when a task's status changes"
    args_schema: Type[BaseModel] = PublishTaskStatusUpdateInput
    
    def _run(self, task_id: int, old_status: str, new_status: str, **kwargs) -> str:
        """Publish task status update event"""
        message = {
            'task_id': task_id,
            'old_status': old_status,
            'new_status': new_status,
            **kwargs
        }
        success = self._publish_event(
            channel=f"event:{kwargs['event_id']}:task_status_update",
            message=message
        )
        return json.dumps({
            "success": success,
            "message": f"Published status update for task {task_id}: {old_status} -> {new_status}"
        })


class SubscribeToEventsInput(BaseModel):
    event_id: int
    channels: list[str]


class SubscribeToEventsTool(MCPPublisher):
    name: str = "Subscribe to MCP Events"
    description: str = "Subscribe to specific MCP channels to receive updates from other agents"
    args_schema: Type[BaseModel] = SubscribeToEventsInput
    
    def _run(self, event_id: int, channels: list[str]) -> str:
        """Subscribe to MCP channels and return recent messages"""
        redis_client = self._get_redis_client()
        if not redis_client:
            return json.dumps({
                "success": True,
                "subscribed_channels": channels,
                "recent_messages": "MCP is disabled."
            })
            
        try:
            messages = []
            for channel in channels:
                stream_key = f"mcp:stream:{channel}"
                stream_messages = redis_client.xrevrange(stream_key, count=10)
                
                for msg_id, msg_data in stream_messages:
                    messages.append({
                        "channel": channel,
                        "message_id": msg_id,
                        "data": msg_data
                    })
            
            return json.dumps({
                "success": True,
                "subscribed_channels": channels,
                "recent_messages": messages
            })
        except Exception as e:
            return json.dumps({
                "success": False,
                "error": str(e)
            })