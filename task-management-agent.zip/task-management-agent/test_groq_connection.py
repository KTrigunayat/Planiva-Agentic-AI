"""
Diagnostic script to test Groq API connection and model availability
Run this before running your main application
"""

import os
from dotenv import load_dotenv
from langchain_groq import ChatGroq
import requests

load_dotenv()

def test_groq_api_key():
    """Test if Groq API key is set"""
    api_key = os.getenv("GROQ_API_KEY")
    if not api_key:
        print("❌ GROQ_API_KEY not found in environment variables")
        return False
    print(f"✅ GROQ_API_KEY found: {api_key[:8]}...{api_key[-4:]}")
    return True

def test_available_models():
    """Test which models are available with your API key"""
    api_key = os.getenv("GROQ_API_KEY")
    url = "https://api.groq.com/openai/v1/models"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            models = response.json()
            print("\n✅ Available models:")
            for model in models.get('data', []):
                model_id = model.get('id', 'unknown')
                print(f"   - {model_id}")
            return models.get('data', [])
        else:
            print(f"❌ Failed to fetch models: {response.status_code}")
            print(f"   Response: {response.text}")
            return []
    except Exception as e:
        print(f"❌ Error fetching models: {e}")
        return []

def test_model_inference(model_name="llama-3.3-70b-versatile"):
    """Test if we can run inference with the specified model"""
    try:
        print(f"\n🔄 Testing inference with {model_name}...")
        llm = ChatGroq(
            api_key=os.getenv("GROQ_API_KEY"),
            model_name=model_name,
            temperature=0.1,
            max_tokens=100,
            timeout=30,
            max_retries=2
        )
        
        response = llm.invoke("Say 'Hello, I am working!' in one sentence.")
        print(f"✅ Model {model_name} is working!")
        print(f"   Response: {response.content}")
        return True
    except Exception as e:
        print(f"❌ Model {model_name} failed: {str(e)}")
        return False

def check_rate_limits():
    """Check current rate limit status"""
    print("\n📊 Rate Limit Information:")
    print("   Free tier limits:")
    print("   - llama-3.3-70b-versatile: 30,000 TPM, 30 RPM")
    print("   - llama-3.1-8b-instant: 6,000 TPM, 30 RPM")
    print("   Recommendation: Use 70B model for better limits and quality")

def main():
    print("="*60)
    print("🔧 Groq API Diagnostic Tool")
    print("="*60)
    
    # Test 1: API Key
    if not test_groq_api_key():
        print("\n❌ CRITICAL: Set GROQ_API_KEY in your .env file")
        return
    
    # Test 2: Available Models
    models = test_available_models()
    
    # Test 3: Model Inference
    if models:
        # Try the 70B model first
        if not test_model_inference("llama-3.3-70b-versatile"):
            # Fallback to 8B if 70B fails
            print("\n⚠️  70B model failed, trying 8B model...")
            test_model_inference("llama-3.1-8b-instant")
    
    # Test 4: Rate Limits Info
    check_rate_limits()
    
    print("\n" + "="*60)
    print("✅ Diagnostic complete!")
    print("="*60)

if __name__ == "__main__":
    main()