"""
Database connection and initialization module
"""

import psycopg2
from psycopg2.extras import RealDictCursor
import os
from dotenv import load_dotenv
import logging
import json  

# Load environment variables
load_dotenv()

logger = logging.getLogger(__name__)


def get_db_connection():
    """
    Create and return a database connection
    
    Returns:
        psycopg2 connection object
    """
    try:
        connection = psycopg2.connect(
            os.getenv("DATABASE_URL"),
            cursor_factory=RealDictCursor
        )
        return connection
    except Exception as e:
        logger.error(f"Database connection error: {e}")
        raise


def init_database():
    """
    Initialize database with required tables
    Runs the migrations.sql file
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Read and execute migrations
        migrations_path = os.path.join(
            os.path.dirname(__file__),
            'migrations.sql'
        )
        
        with open(migrations_path, 'r') as f:
            sql = f.read()
        
        cursor.execute(sql)
        conn.commit()
        
        cursor.close()
        conn.close()
        
        logger.info("Database initialized successfully")
        
    except Exception as e:
        logger.error(f"Error initializing database: {e}")
        raise


def seed_sample_data():
    """
    Seed the database with sample vendors for testing
    """
    try:
        print("Seeding sample data...")
        conn = get_db_connection()
        cursor = conn.cursor()

        sample_vendors = [
            {
                'name': 'Grand Venue Hall',
                'services': ['venue', 'decor'],
                'capacity': 500,
                'rating': 4.8,
                'price_estimates': {'venue_rental': 150000, 'decor_package': 50000},
                'location': 'Bangalore, Karnataka',
                'contact_info': {'phone': '+91-9876543210', 'email': 'contact@grandvenue.com'}
            },
            {
                'name': 'Gourmet Catering Co.',
                'services': ['catering', 'beverages'],
                'capacity': 1000,
                'rating': 4.9,
                'price_estimates': {'per_plate_veg': 1200, 'per_plate_nonveg': 1500},
                'location': 'Bangalore, Karnataka',
                'contact_info': {'phone': '+91-9876543211', 'email': 'sales@gourmetcatering.com'}
            },
            {
                'name': 'Pro Audio Visuals',
                'services': ['audio', 'lighting', 'projection'],
                'capacity': None,
                'rating': 4.6,
                'price_estimates': {'basic_audio': 30000, 'full_lighting': 75000},
                'location': 'Bangalore, Karnataka',
                'contact_info': {'phone': '+91-9876543212', 'email': 'info@proav.com'}
            },
            {
                'name': 'Elegant Decorators',
                'services': ['decor', 'floral_arrangements'],
                'capacity': None,
                'rating': 4.7,
                'price_estimates': {'standard_decor': 60000, 'floral_package': 40000},
                'location': 'Bangalore, Karnataka',
                'contact_info': {'phone': '+91-9876543213', 'email': 'hello@elegantdecorators.com'}
            },
            {
                'name': 'Swift Photography',
                'services': ['photography', 'videography'],
                'capacity': None,
                'rating': 4.7,
                'price_estimates': {'photography': 40000, 'videography': 50000},
                'location': 'Bangalore, Karnataka',
                'contact_info': {'phone': '+91-9876543214', 'email': 'bookings@swiftphoto.com'}
            }
        ]
        
        for vendor in sample_vendors:
            cursor.execute("""
                INSERT INTO vendors (name, services, capacity, rating, price_estimates, location, contact_info)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT DO NOTHING
            """, (
                vendor['name'],
                vendor['services'],
                vendor['capacity'],
                vendor['rating'],
                json.dumps(vendor['price_estimates']),  # <-- FIX 2: CONVERT DICT TO JSON STRING
                vendor['location'],
                json.dumps(vendor['contact_info'])      # <-- FIX 3: CONVERT DICT TO JSON STRING
            ))
        
        conn.commit()
        cursor.close()
        conn.close()
        
        logger.info("Sample vendor data seeded successfully")
        
    except Exception as e:
        logger.error(f"Error seeding data: {e}")
        raise


if __name__ == "__main__":
    print("Initializing database...")
    init_database()
    seed_sample_data()