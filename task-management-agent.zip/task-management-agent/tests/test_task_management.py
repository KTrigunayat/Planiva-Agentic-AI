"""
Test suite for Task Management Agent
"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from datetime import datetime, timedelta
from src.models.schemas import EventBlueprint, BlueprintMilestone
from src.crews.task_management_crew import TaskManagementCrew
import json


def create_sample_blueprint():
    """Create a sample event blueprint for testing"""
    
    event_date = datetime.now() + timedelta(days=30)
    
    milestones = [
        BlueprintMilestone(
            milestone_name="Venue Setup",
            description="Setup venue including stage, seating, and basic arrangements",
            start_time=event_date.replace(hour=8, minute=0),
            end_time=event_date.replace(hour=10, minute=0),
            duration_minutes=120,
            responsible_party="Grand Venue Hall",
            dependencies=[],
            deliverables=["Stage setup complete", "Seating arranged", "Entrance decorated"],
            vendor_id=1,
            metadata={"sub_event": "preparation"}
        ),
        BlueprintMilestone(
            milestone_name="Audio-Visual Setup",
            description="Install and test audio, lighting, and projection systems",
            start_time=event_date.replace(hour=10, minute=0),
            end_time=event_date.replace(hour=12, minute=0),
            duration_minutes=120,
            responsible_party="Pro Audio Systems",
            dependencies=["Venue Setup"],
            deliverables=["Audio system installed", "Lighting setup complete", "Sound check done"],
            vendor_id=3,
            metadata={"sub_event": "preparation"}
        ),
        BlueprintMilestone(
            milestone_name="Decoration Setup",
            description="Complete floral arrangements and theme-based decoration",
            start_time=event_date.replace(hour=10, minute=30),
            end_time=event_date.replace(hour=13, minute=0),
            duration_minutes=150,
            responsible_party="Elegant Decorations",
            dependencies=["Venue Setup"],
            deliverables=["Floral arrangements complete", "Theme decorations installed", "Photo booth setup"],
            vendor_id=4,
            metadata={"sub_event": "preparation"}
        ),
        BlueprintMilestone(
            milestone_name="Catering Preparation",
            description="Setup catering station and food preparation area",
            start_time=event_date.replace(hour=13, minute=0),
            end_time=event_date.replace(hour=15, minute=0),
            duration_minutes=120,
            responsible_party="Delicious Catering Co",
            dependencies=["Venue Setup"],
            deliverables=["Catering station setup", "Food warmers installed", "Buffet area ready"],
            vendor_id=2,
            metadata={"sub_event": "preparation"}
        ),
        BlueprintMilestone(
            milestone_name="Guest Registration",
            description="Setup registration desk and welcome guests",
            start_time=event_date.replace(hour=15, minute=0),
            end_time=event_date.replace(hour=16, minute=0),
            duration_minutes=60,
            responsible_party="Internal Coordination Team",
            dependencies=["Venue Setup", "Decoration Setup"],
            deliverables=["Registration desk active", "Welcome materials distributed"],
            metadata={"sub_event": "main_event"}
        ),
        BlueprintMilestone(
            milestone_name="Main Event Session",
            description="Main event program including speeches and presentations",
            start_time=event_date.replace(hour=16, minute=0),
            end_time=event_date.replace(hour=19, minute=0),
            duration_minutes=180,
            responsible_party="Internal Coordination Team",
            dependencies=["Guest Registration", "Audio-Visual Setup"],
            deliverables=["All sessions completed", "Program schedule followed"],
            metadata={"sub_event": "main_event"}
        ),
        BlueprintMilestone(
            milestone_name="Dinner Service",
            description="Serve dinner to all guests",
            start_time=event_date.replace(hour=19, minute=0),
            end_time=event_date.replace(hour=21, minute=0),
            duration_minutes=120,
            responsible_party="Delicious Catering Co",
            dependencies=["Catering Preparation", "Main Event Session"],
            deliverables=["All guests served", "Food quality maintained"],
            vendor_id=2,
            metadata={"sub_event": "main_event"}
        ),
        BlueprintMilestone(
            milestone_name="Photography Coverage",
            description="Capture event photos and videos throughout",
            start_time=event_date.replace(hour=15, minute=0),
            end_time=event_date.replace(hour=22, minute=0),
            duration_minutes=420,
            responsible_party="Swift Photography",
            dependencies=["Guest Registration"],
            deliverables=["Key moments captured", "Group photos taken", "Video footage recorded"],
            vendor_id=5,
            metadata={"sub_event": "continuous"}
        ),
        BlueprintMilestone(
            milestone_name="Event Teardown",
            description="Clean up and dismantle all setups",
            start_time=event_date.replace(hour=22, minute=0),
            end_time=event_date.replace(hour=23, minute=30),
            duration_minutes=90,
            responsible_party="Grand Venue Hall",
            dependencies=["Dinner Service"],
            deliverables=["Venue cleaned", "All equipment packed", "Final inspection done"],
            vendor_id=1,
            metadata={"sub_event": "teardown"}
        )
    ]
    
    blueprint = EventBlueprint(
        event_id=1001,
        plan_id=5001,
        event_title="TIE Bangalore Annual Conference 2025",
        event_date=event_date,
        milestones=milestones,
        vendors=[
            {"id": 1, "name": "Grand Venue Hall", "service": "venue"},
            {"id": 2, "name": "Delicious Catering Co", "service": "catering"},
            {"id": 3, "name": "Pro Audio Systems", "service": "audio_visual"},
            {"id": 4, "name": "Elegant Decorations", "service": "decoration"},
            {"id": 5, "name": "Swift Photography", "service": "photography"}
        ],
        budget_allocation={
            "venue": 50000,
            "catering": 120000,
            "audio_visual": 40000,
            "decoration": 40000,
            "photography": 90000
        },
        metadata={
            "expected_guests": 200,
            "event_type": "conference",
            "theme": "innovation_tech"
        }
    )
    
    return blueprint


def test_full_workflow():
    """Test the complete task management workflow"""
    print("=" * 70)
    print("Testing Full Task Management Workflow")
    print("=" * 70)
    
    # Create sample blueprint
    blueprint = create_sample_blueprint()
    print(f"\n✓ Created sample blueprint for event: {blueprint.event_title}")
    print(f"  Event Date: {blueprint.event_date}")
    print(f"  Number of Milestones: {len(blueprint.milestones)}")
    
    # Initialize crew
    print("\n✓ Initializing Task Management Crew...")
    crew = TaskManagementCrew()
    
    # Run full workflow
    print("\n✓ Starting full workflow execution...")
    print("  This includes:")
    print("    1. Creating tasks from blueprint")
    print("    2. Assigning tasks to vendors")
    print("    3. Setting up monitoring")
    print("\n" + "-" * 70)
    
    try:
        result = crew.run_full_workflow(blueprint.dict())
        
        print("\n" + "=" * 70)
        print("Workflow Execution Complete!")
        print("=" * 70)
        print(f"\nEvent ID: {result['event_id']}")
        print(f"Plan ID: {result['plan_id']}")
        print(f"Success: {result['success']}")
        print("\nResult Summary:")
        print(result['result'])
        
    except Exception as e:
        print(f"\n✗ Error during workflow execution: {e}")
        import traceback
        traceback.print_exc()


def test_task_creation_only():
    """Test only the task creation phase"""
    print("=" * 70)
    print("Testing Task Creation Phase Only")
    print("=" * 70)
    
    blueprint = create_sample_blueprint()
    crew = TaskManagementCrew()
    
    # Create task creation task
    task_creation = crew.create_tasks_from_blueprint(blueprint.dict())
    
    print(f"\n✓ Task creation configured for event: {blueprint.event_title}")
    print(f"  Agent: {task_creation.agent.role}")
    print(f"  Expected Output: {task_creation.expected_output[:100]}...")
    
    from crewai import Crew, Process
    
    mini_crew = Crew(
        agents=[crew.task_maker],
        tasks=[task_creation],
        process=Process.sequential,
        verbose=True
    )
    
    try:
        result = mini_crew.kickoff()
        print("\n" + "=" * 70)
        print("Task Creation Complete!")
        print("=" * 70)
        print("\nResult:")
        print(result)
        
    except Exception as e:
        print(f"\n✗ Error: {e}")
        import traceback
        traceback.print_exc()


def test_tools_individually():
    """Test individual tools"""
    print("=" * 70)
    print("Testing Individual Tools")
    print("=" * 70)
    
    from src.tools.database_tools import CreateTaskTool, GetTasksTool
    from src.tools.mcp_tools import PublishTaskCreatedTool
    
    # Test CreateTaskTool
    print("\n1. Testing CreateTaskTool...")
    create_tool = CreateTaskTool()
    
    result = create_tool._run(
        plan_id=5001,
        event_id=1001,
        title="Test Task",
        description="This is a test task",
        owner_type="vendor",
        due_date=(datetime.now() + timedelta(days=7)).isoformat(),
        priority="high"
    )
    
    print(f"   Result: {result}")
    
    # Test GetTasksTool
    print("\n2. Testing GetTasksTool...")
    get_tool = GetTasksTool()
    
    result = get_tool._run(event_id=1001)
    print(f"   Result: {result[:200]}...")
    
    # Test MCP Publisher
    print("\n3. Testing MCP PublishTaskCreatedTool...")
    mcp_tool = PublishTaskCreatedTool()
    
    result = mcp_tool._run(
        task_id=1,
        event_id=1001,
        plan_id=5001,
        title="Test Task",
        owner_type="vendor",
        due_date=(datetime.now() + timedelta(days=7)).isoformat()
    )
    
    print(f"   Result: {result}")


if __name__ == "__main__":
    print("\n" + "=" * 70)
    print("PLANIVA TASK MANAGEMENT AGENT - TEST SUITE")
    print("=" * 70)
    
    # You can choose which test to run
    import sys
    
    if len(sys.argv) > 1:
        test_type = sys.argv[1]
        
        if test_type == "full":
            test_full_workflow()
        elif test_type == "create":
            test_task_creation_only()
        elif test_type == "tools":
            test_tools_individually()
        else:
            print(f"Unknown test type: {test_type}")
            print("Available tests: full, create, tools")
    else:
        print("\nUsage: python test_task_management.py [test_type]")
        print("Available test types:")
        print("  full   - Test complete workflow")
        print("  create - Test task creation only")
        print("  tools  - Test individual tools")
        print("\nRunning default test (tools)...")
        test_tools_individually()