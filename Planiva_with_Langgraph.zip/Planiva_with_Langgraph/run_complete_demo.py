#!/usr/bin/env python3
"""
Complete Demo Runner for Event Planning Agent v2
This script starts the API server and runs the complete demo
"""

import subprocess
import sys
import time
import os
import signal
from pathlib import Path

class CompleteDemoRunner:
    """Runner for the complete Event Planning Agent v2 demo"""
    
    def __init__(self):
        self.api_process = None
        self.base_dir = Path(__file__).parent
        
    def print_header(self, title: str):
        """Print formatted header"""
        print("\n" + "=" * 80)
        print(f"🎉 {title}")
        print("=" * 80)
    
    def check_requirements(self) -> bool:
        """Check if all requirements are met"""
        print("🔍 Checking requirements...")
        
        # Check Python version
        if sys.version_info < (3, 8):
            print("❌ Python 3.8+ required")
            return False
        print(f"✅ Python {sys.version_info.major}.{sys.version_info.minor}")
        
        # Check if event_planning_agent_v2 directory exists
        agent_dir = self.base_dir / "event_planning_agent_v2"
        if not agent_dir.exists():
            print("❌ event_planning_agent_v2 directory not found")
            return False
        print("✅ Event Planning Agent v2 directory found")
        
        # Check if demo script exists
        demo_script = agent_dir / "demo_priya_rohit.py"
        if not demo_script.exists():
            print("❌ Demo script not found")
            return False
        print("✅ Demo script found")
        
        return True
    
    def install_dependencies(self) -> bool:
        """Install required dependencies"""
        print("\n📦 Installing dependencies...")
        
        try:
            # Install demo requirements (simplified)
            agent_dir = self.base_dir / "event_planning_agent_v2"
            demo_requirements_file = agent_dir / "requirements_demo.txt"
            requirements_file = agent_dir / "requirements.txt"
            
            # Try demo requirements first (minimal dependencies)
            if demo_requirements_file.exists():
                print("Installing minimal demo requirements...")
                result = subprocess.run([
                    sys.executable, "-m", "pip", "install", "-r", str(demo_requirements_file)
                ], capture_output=True, text=True)
            elif requirements_file.exists():
                print("Installing Event Planning Agent v2 requirements...")
                result = subprocess.run([
                    sys.executable, "-m", "pip", "install", "-r", str(requirements_file)
                ], capture_output=True, text=True)
                
                if result.returncode != 0:
                    print(f"❌ Failed to install requirements: {result.stderr}")
                    return False
                print("✅ Dependencies installed")
            else:
                print("⚠️ No requirements.txt found, continuing...")
            
            return True
            
        except Exception as e:
            print(f"❌ Error installing dependencies: {e}")
            return False
    
    def start_api_server(self) -> bool:
        """Start the Event Planning Agent v2 API server"""
        print("\n🚀 Starting Event Planning Agent v2 API server...")
        
        try:
            agent_dir = self.base_dir / "event_planning_agent_v2"
            
            # Change to the agent directory
            os.chdir(agent_dir)
            
            # Start the API server
            self.api_process = subprocess.Popen([
                sys.executable, "main.py"
            ], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            
            # Wait a bit for server to start
            print("⏳ Waiting for API server to start...")
            time.sleep(10)
            
            # Check if process is still running
            if self.api_process.poll() is None:
                print("✅ API server started successfully")
                print("🌐 Server running at: http://localhost:8000")
                return True
            else:
                stdout, stderr = self.api_process.communicate()
                print(f"❌ API server failed to start")
                print(f"Error: {stderr}")
                return False
                
        except Exception as e:
            print(f"❌ Error starting API server: {e}")
            return False
    
    def run_demo(self) -> bool:
        """Run the Priya & Rohit demo"""
        print("\n🎭 Running Priya & Rohit Wedding Demo...")
        
        try:
            agent_dir = self.base_dir / "event_planning_agent_v2"
            demo_script = agent_dir / "demo_priya_rohit.py"
            
            # Run the demo script
            result = subprocess.run([
                sys.executable, str(demo_script)
            ], cwd=agent_dir, text=True)
            
            if result.returncode == 0:
                print("✅ Demo completed successfully!")
                return True
            else:
                print(f"❌ Demo failed with return code: {result.returncode}")
                return False
                
        except Exception as e:
            print(f"❌ Error running demo: {e}")
            return False
    
    def cleanup(self):
        """Clean up processes"""
        print("\n🧹 Cleaning up...")
        
        if self.api_process and self.api_process.poll() is None:
            print("🛑 Stopping API server...")
            self.api_process.terminate()
            
            # Wait for graceful shutdown
            try:
                self.api_process.wait(timeout=5)
                print("✅ API server stopped")
            except subprocess.TimeoutExpired:
                print("⚠️ Force killing API server...")
                self.api_process.kill()
                self.api_process.wait()
    
    def run_complete_demo(self):
        """Run the complete demo workflow"""
        self.print_header("Event Planning Agent v2 - Complete Demo Runner")
        
        print("🎯 This will run the complete Event Planning Agent v2 system:")
        print("   1. Check requirements")
        print("   2. Install dependencies") 
        print("   3. Start API server")
        print("   4. Run Priya & Rohit wedding demo")
        print("   5. Display all functionalities")
        
        try:
            # Step 1: Check requirements
            if not self.check_requirements():
                print("\n❌ Requirements check failed")
                return False
            
            # Step 2: Install dependencies
            if not self.install_dependencies():
                print("\n❌ Dependency installation failed")
                return False
            
            # Step 3: Start API server
            if not self.start_api_server():
                print("\n❌ API server startup failed")
                return False
            
            # Step 4: Run demo
            demo_success = self.run_demo()
            
            # Step 5: Show results
            if demo_success:
                self.print_header("🎉 Complete Demo Finished Successfully!")
                print("✅ All Event Planning Agent v2 functionalities demonstrated:")
                print("   ✓ Multi-agent AI system")
                print("   ✓ Real-time progress tracking")
                print("   ✓ Intelligent vendor matching")
                print("   ✓ Automated combination scoring")
                print("   ✓ Comprehensive blueprint generation")
                print("   ✓ Multi-format export")
                
                print(f"\n🎊 Priya & Rohit's wedding plan generated successfully!")
                print(f"📁 Check the generated files in event_planning_agent_v2/")
            else:
                print("\n⚠️ Demo completed with issues")
            
            return demo_success
            
        except KeyboardInterrupt:
            print("\n\n⏹️ Demo interrupted by user")
            return False
        except Exception as e:
            print(f"\n❌ Demo failed: {e}")
            import traceback
            traceback.print_exc()
            return False
        finally:
            self.cleanup()

def main():
    """Main entry point"""
    runner = CompleteDemoRunner()
    
    try:
        success = runner.run_complete_demo()
        
        if success:
            print("\n🌟 Demo completed successfully!")
            print("💡 You can now explore the generated wedding plan files")
        else:
            print("\n⚠️ Demo had some issues")
            print("💡 Check the error messages above and try again")
        
        input("\nPress Enter to exit...")
        return success
        
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        input("\nPress Enter to exit...")
        return False

if __name__ == "__main__":
    main()