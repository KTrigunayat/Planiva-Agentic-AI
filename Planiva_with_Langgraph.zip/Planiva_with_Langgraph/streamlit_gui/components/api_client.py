"""
API client for Event Planning Agent v2 integration
"""
import asyncio
import time
import hashlib
import json
from typing import Dict, List, Optional, Any
import requests
import aiohttp
from asyncio_throttle import Throttler
import streamlit as st
from utils.config import config

class APIError(Exception):
    """Custom exception for API errors"""
    def __init__(self, message: str, status_code: Optional[int] = None, response_data: Optional[Dict] = None):
        self.message = message
        self.status_code = status_code
        self.response_data = response_data
        super().__init__(self.message)

class APIClient:
    """
    API client for Event Planning Agent v2 backend
    Handles all communication with the FastAPI backend with caching support
    """
    
    def __init__(self):
        self.base_url = config.API_BASE_URL
        self.timeout = config.API_TIMEOUT
        self.retry_attempts = config.API_RETRY_ATTEMPTS
        self.retry_delay = config.API_RETRY_DELAY
        self.throttler = Throttler(rate_limit=10, period=1)  # 10 requests per second
        self.cache_ttl = config.get("CACHE_TTL", 300)  # 5 minutes default
        
    def _get_cache_key(self, method: str, endpoint: str, **kwargs) -> str:
        """Generate a cache key for the request"""
        cache_data = {
            "method": method,
            "endpoint": endpoint,
            "params": kwargs.get("params", {}),
            "json": kwargs.get("json", {})
        }
        cache_string = json.dumps(cache_data, sort_keys=True)
        return hashlib.md5(cache_string.encode()).hexdigest()
    
    def _is_cacheable(self, method: str, endpoint: str) -> bool:
        """Determine if a request should be cached"""
        # Only cache GET requests and specific endpoints
        if method != "GET":
            return False
        
        cacheable_endpoints = [
            "/health",
            "/v1/plans",  # List plans
        ]
        
        # Cache plan details and status for a short time
        if "/v1/plans/" in endpoint and any(suffix in endpoint for suffix in ["/status", "/results", "/blueprint"]):
            return True
            
        return any(endpoint.startswith(cacheable) for cacheable in cacheable_endpoints)
    
    @st.cache_data(ttl=300, show_spinner=False)
    def _cached_request(_self, cache_key: str, method: str, endpoint: str, **kwargs) -> Dict:
        """Cached version of _make_request"""
        return _self._make_request_uncached(method, endpoint, **kwargs)
    
    def _make_request_uncached(self, method: str, endpoint: str, **kwargs) -> Dict:
        """Make request without caching (original implementation)"""
        url = config.get_api_url(endpoint)
        
        for attempt in range(self.retry_attempts):
            try:
                response = requests.request(
                    method=method,
                    url=url,
                    timeout=self.timeout,
                    **kwargs
                )
                
                if response.status_code == 200:
                    return response.json()
                elif response.status_code == 404:
                    raise APIError(f"Endpoint not found: {endpoint}", response.status_code)
                elif response.status_code >= 500:
                    # Server error - retry
                    if attempt < self.retry_attempts - 1:
                        time.sleep(self.retry_delay * (attempt + 1))
                        continue
                    raise APIError(f"Server error: {response.status_code}", response.status_code)
                else:
                    # Client error - don't retry
                    error_data = None
                    try:
                        error_data = response.json()
                    except:
                        pass
                    raise APIError(f"Request failed: {response.status_code}", response.status_code, error_data)
                    
            except requests.exceptions.ConnectionError:
                if attempt < self.retry_attempts - 1:
                    time.sleep(self.retry_delay * (attempt + 1))
                    continue
                raise APIError("Cannot connect to API server")
            except requests.exceptions.Timeout:
                if attempt < self.retry_attempts - 1:
                    time.sleep(self.retry_delay * (attempt + 1))
                    continue
                raise APIError("Request timeout")
            except requests.exceptions.RequestException as e:
                raise APIError(f"Request error: {str(e)}")
        
        raise APIError("Max retry attempts exceeded")
        
    def _make_request(self, method: str, endpoint: str, **kwargs) -> Dict:
        """
        Make a synchronous HTTP request with caching and retry logic
        """
        # Check if request should be cached
        if self._is_cacheable(method, endpoint):
            cache_key = self._get_cache_key(method, endpoint, **kwargs)
            return self._cached_request(cache_key, method, endpoint, **kwargs)
        else:
            return self._make_request_uncached(method, endpoint, **kwargs)
    
    async def _make_async_request(self, method: str, endpoint: str, **kwargs) -> Dict:
        """
        Make an asynchronous HTTP request with retry logic
        """
        url = config.get_api_url(endpoint)
        
        async with self.throttler:
            for attempt in range(self.retry_attempts):
                try:
                    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=self.timeout)) as session:
                        async with session.request(method, url, **kwargs) as response:
                            if response.status == 200:
                                return await response.json()
                            elif response.status == 404:
                                raise APIError(f"Endpoint not found: {endpoint}", response.status)
                            elif response.status >= 500:
                                # Server error - retry
                                if attempt < self.retry_attempts - 1:
                                    await asyncio.sleep(self.retry_delay * (attempt + 1))
                                    continue
                                raise APIError(f"Server error: {response.status}", response.status)
                            else:
                                # Client error - don't retry
                                error_data = None
                                try:
                                    error_data = await response.json()
                                except:
                                    pass
                                raise APIError(f"Request failed: {response.status}", response.status, error_data)
                                
                except aiohttp.ClientConnectorError:
                    if attempt < self.retry_attempts - 1:
                        await asyncio.sleep(self.retry_delay * (attempt + 1))
                        continue
                    raise APIError("Cannot connect to API server")
                except asyncio.TimeoutError:
                    if attempt < self.retry_attempts - 1:
                        await asyncio.sleep(self.retry_delay * (attempt + 1))
                        continue
                    raise APIError("Request timeout")
                except Exception as e:
                    raise APIError(f"Request error: {str(e)}")
        
        raise APIError("Max retry attempts exceeded")
    
    def health_check(self) -> Dict:
        """
        Check API server health
        """
        try:
            return self._make_request("GET", "/health")
        except APIError:
            return {"status": "unhealthy", "error": "Cannot connect to server"}
    
    def create_plan(self, request_data: Dict) -> Dict:
        """
        Create a new event plan (synchronous)
        """
        return self._make_request("POST", "/v1/plans", json=request_data)
    
    async def create_plan_async(self, request_data: Dict) -> Dict:
        """
        Create a new event plan (asynchronous)
        """
        return await self._make_async_request("POST", "/v1/plans", json=request_data)
    
    def get_plan_status(self, plan_id: str) -> Dict:
        """
        Get the status of an event plan
        """
        return self._make_request("GET", f"/v1/plans/{plan_id}/status")
    
    def get_plan_results(self, plan_id: str) -> Dict:
        """
        Get the results/combinations for an event plan
        """
        return self._make_request("GET", f"/v1/plans/{plan_id}/results")
    
    def select_combination(self, plan_id: str, combination_id: str) -> Dict:
        """
        Select a vendor combination for an event plan
        """
        return self._make_request("POST", f"/v1/plans/{plan_id}/select", json={"combination_id": combination_id})
    
    def get_blueprint(self, plan_id: str) -> Dict:
        """
        Get the final blueprint for an event plan
        """
        return self._make_request("GET", f"/v1/plans/{plan_id}/blueprint")
    
    def list_plans(self, limit: int = 50, offset: int = 0) -> Dict:
        """
        List all event plans
        """
        params = {"limit": limit, "offset": offset}
        return self._make_request("GET", "/v1/plans", params=params)
    
    def get_plan_details(self, plan_id: str) -> Dict:
        """
        Get detailed information about a specific plan
        """
        return self._make_request("GET", f"/v1/plans/{plan_id}")
    
    def delete_plan(self, plan_id: str) -> Dict:
        """
        Delete an event plan
        """
        return self._make_request("DELETE", f"/v1/plans/{plan_id}")
    
    async def stream_plan_status(self, plan_id: str, callback):
        """
        Stream real-time status updates for a plan
        """
        while True:
            try:
                status = await self._make_async_request("GET", f"/v1/plans/{plan_id}/status")
                callback(status)
                
                # Check if plan is complete
                if status.get("status") in ["completed", "failed", "cancelled"]:
                    break
                    
                await asyncio.sleep(2)  # Poll every 2 seconds
                
            except APIError as e:
                callback({"status": "error", "error": str(e)})
                break

# Global API client instance
api_client = APIClient()