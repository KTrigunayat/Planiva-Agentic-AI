"""
CSS styles for the Streamlit GUI components
"""

# CSS for results display components
RESULTS_CSS = """
<style>
    /* Combination card styling */
    .combination-card {
        border: 1px solid #e0e0e0;
        border-radius: 12px;
        padding: 1.5rem;
        margin-bottom: 1rem;
        background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        transition: all 0.3s ease;
    }
    
    .combination-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 15px rgba(0, 0, 0, 0.15);
        border-color: #007bff;
    }
    
    .combination-card.selected {
        border-color: #28a745;
        background: linear-gradient(135deg, #f8fff9 0%, #e8f5e9 100%);
    }
    
    /* Fitness score styling */
    .fitness-score {
        font-size: 2rem;
        font-weight: bold;
        color: #28a745;
        text-align: center;
    }
    
    .fitness-score.excellent {
        color: #28a745;
    }
    
    .fitness-score.good {
        color: #ffc107;
    }
    
    .fitness-score.fair {
        color: #fd7e14;
    }
    
    .fitness-score.poor {
        color: #dc3545;
    }
    
    /* Cost display styling */
    .cost-display {
        font-size: 1.5rem;
        font-weight: bold;
        color: #007bff;
        text-align: center;
    }
    
    /* Vendor info styling */
    .vendor-info {
        background-color: #f8f9fa;
        border-radius: 8px;
        padding: 1rem;
        margin: 0.5rem 0;
    }
    
    .vendor-name {
        font-weight: bold;
        color: #495057;
        margin-bottom: 0.25rem;
    }
    
    .vendor-details {
        font-size: 0.9rem;
        color: #6c757d;
    }
    
    /* Comparison table styling */
    .comparison-table {
        border-collapse: collapse;
        width: 100%;
        margin: 1rem 0;
    }
    
    .comparison-table th,
    .comparison-table td {
        border: 1px solid #dee2e6;
        padding: 0.75rem;
        text-align: left;
    }
    
    .comparison-table th {
        background-color: #e9ecef;
        font-weight: bold;
    }
    
    .comparison-table tr:nth-child(even) {
        background-color: #f8f9fa;
    }
    
    .comparison-table tr:hover {
        background-color: #e3f2fd;
    }
    
    /* Plan management styling */
    .plan-card {
        border: 1px solid #dee2e6;
        border-radius: 8px;
        padding: 1rem;
        margin-bottom: 1rem;
        background-color: #ffffff;
        transition: all 0.2s ease;
    }
    
    .plan-card:hover {
        border-color: #007bff;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    
    .plan-status {
        display: inline-block;
        padding: 0.25rem 0.5rem;
        border-radius: 4px;
        font-size: 0.8rem;
        font-weight: bold;
        text-transform: uppercase;
    }
    
    .plan-status.completed {
        background-color: #d4edda;
        color: #155724;
    }
    
    .plan-status.in-progress {
        background-color: #cce7ff;
        color: #004085;
    }
    
    .plan-status.pending {
        background-color: #fff3cd;
        color: #856404;
    }
    
    .plan-status.failed {
        background-color: #f8d7da;
        color: #721c24;
    }
    
    .plan-status.cancelled {
        background-color: #e2e3e5;
        color: #383d41;
    }
    
    /* Action buttons */
    .action-button {
        margin: 0.25rem;
        padding: 0.5rem 1rem;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-weight: bold;
        transition: all 0.2s ease;
    }
    
    .action-button.primary {
        background-color: #007bff;
        color: white;
    }
    
    .action-button.primary:hover {
        background-color: #0056b3;
    }
    
    .action-button.success {
        background-color: #28a745;
        color: white;
    }
    
    .action-button.success:hover {
        background-color: #1e7e34;
    }
    
    .action-button.danger {
        background-color: #dc3545;
        color: white;
    }
    
    .action-button.danger:hover {
        background-color: #c82333;
    }
    
    /* Loading animations */
    .loading-spinner {
        border: 4px solid #f3f3f3;
        border-top: 4px solid #007bff;
        border-radius: 50%;
        width: 40px;
        height: 40px;
        animation: spin 1s linear infinite;
        margin: 20px auto;
    }
    
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    
    /* Responsive design */
    @media (max-width: 1200px) {
        .combination-card {
            margin-bottom: 1.5rem;
        }
        
        .comparison-table {
            font-size: 0.9rem;
        }
    }
    
    @media (max-width: 992px) {
        .combination-card {
            padding: 1.25rem;
        }
        
        .vendor-info {
            padding: 0.75rem;
        }
        
        .comparison-table th,
        .comparison-table td {
            padding: 0.5rem;
        }
    }
    
    @media (max-width: 768px) {
        .combination-card {
            padding: 1rem;
            margin-bottom: 1rem;
        }
        
        .fitness-score {
            font-size: 1.5rem;
        }
        
        .cost-display {
            font-size: 1.2rem;
        }
        
        .vendor-info {
            padding: 0.5rem;
            margin: 0.25rem 0;
        }
        
        .vendor-name {
            font-size: 0.95rem;
        }
        
        .vendor-details {
            font-size: 0.85rem;
        }
        
        .comparison-table {
            font-size: 0.8rem;
            display: block;
            overflow-x: auto;
            white-space: nowrap;
        }
        
        .action-button {
            padding: 0.4rem 0.8rem;
            font-size: 0.9rem;
            margin: 0.2rem;
        }
        
        .plan-card {
            padding: 0.75rem;
        }
    }
    
    @media (max-width: 576px) {
        .combination-card {
            padding: 0.75rem;
            border-radius: 8px;
        }
        
        .fitness-score {
            font-size: 1.25rem;
        }
        
        .cost-display {
            font-size: 1rem;
        }
        
        .vendor-info {
            padding: 0.4rem;
        }
        
        .vendor-name {
            font-size: 0.9rem;
        }
        
        .vendor-details {
            font-size: 0.8rem;
        }
        
        .action-button {
            padding: 0.3rem 0.6rem;
            font-size: 0.85rem;
            display: block;
            width: 100%;
            margin: 0.2rem 0;
        }
        
        .plan-card {
            padding: 0.5rem;
        }
        
        .plan-status {
            font-size: 0.75rem;
            padding: 0.2rem 0.4rem;
        }
        
        .form-section {
            padding: 1rem;
            margin-bottom: 1rem;
        }
        
        .form-section-title {
            font-size: 1.1rem;
        }
        
        .progress-container {
            padding: 0.75rem;
        }
    }
    
    /* Container responsive utilities */
    .responsive-container {
        max-width: 100%;
        margin: 0 auto;
        padding: 0 1rem;
    }
    
    @media (min-width: 576px) {
        .responsive-container {
            max-width: 540px;
        }
    }
    
    @media (min-width: 768px) {
        .responsive-container {
            max-width: 720px;
        }
    }
    
    @media (min-width: 992px) {
        .responsive-container {
            max-width: 960px;
        }
    }
    
    @media (min-width: 1200px) {
        .responsive-container {
            max-width: 1140px;
        }
    }
    
    /* Mobile-first grid system */
    .row {
        display: flex;
        flex-wrap: wrap;
        margin: 0 -0.5rem;
    }
    
    .col {
        flex: 1;
        padding: 0 0.5rem;
        min-width: 0;
    }
    
    .col-12 { flex: 0 0 100%; max-width: 100%; }
    .col-6 { flex: 0 0 50%; max-width: 50%; }
    .col-4 { flex: 0 0 33.333333%; max-width: 33.333333%; }
    .col-3 { flex: 0 0 25%; max-width: 25%; }
    
    @media (max-width: 768px) {
        .col-md-12 { flex: 0 0 100%; max-width: 100%; }
        .col-6, .col-4, .col-3 {
            flex: 0 0 100%;
            max-width: 100%;
        }
    }
    
    /* Touch-friendly interactions */
    @media (hover: none) and (pointer: coarse) {
        .combination-card:hover {
            transform: none;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        .action-button {
            min-height: 44px;
            min-width: 44px;
        }
        
        .plan-card:hover {
            box-shadow: none;
        }
    }
    
    /* Utility classes */
    .text-center {
        text-align: center;
    }
    
    .text-muted {
        color: #6c757d;
    }
    
    .mb-1 {
        margin-bottom: 0.25rem;
    }
    
    .mb-2 {
        margin-bottom: 0.5rem;
    }
    
    .mb-3 {
        margin-bottom: 1rem;
    }
    
    .mt-1 {
        margin-top: 0.25rem;
    }
    
    .mt-2 {
        margin-top: 0.5rem;
    }
    
    .mt-3 {
        margin-top: 1rem;
    }
</style>
"""

# CSS for form components
FORM_CSS = """
<style>
    /* Form section styling */
    .form-section {
        background-color: #ffffff;
        border: 1px solid #e0e0e0;
        border-radius: 8px;
        padding: 1.5rem;
        margin-bottom: 1.5rem;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
    }
    
    .form-section-header {
        border-bottom: 2px solid #007bff;
        padding-bottom: 0.5rem;
        margin-bottom: 1rem;
    }
    
    .form-section-title {
        font-size: 1.25rem;
        font-weight: bold;
        color: #495057;
        margin: 0;
    }
    
    .form-section-description {
        font-size: 0.9rem;
        color: #6c757d;
        margin-top: 0.25rem;
    }
    
    /* Progress indicator */
    .progress-container {
        background-color: #f8f9fa;
        border-radius: 8px;
        padding: 1rem;
        margin-bottom: 1.5rem;
    }
    
    .progress-bar {
        background-color: #e9ecef;
        border-radius: 4px;
        height: 8px;
        overflow: hidden;
        margin-bottom: 0.5rem;
    }
    
    .progress-fill {
        background-color: #007bff;
        height: 100%;
        transition: width 0.3s ease;
    }
    
    .progress-text {
        font-size: 0.9rem;
        color: #495057;
        text-align: center;
    }
</style>
"""

def get_fitness_score_class(score: float) -> str:
    """Get CSS class based on fitness score"""
    if score >= 90:
        return "excellent"
    elif score >= 75:
        return "good"
    elif score >= 60:
        return "fair"
    else:
        return "poor"

def get_plan_status_class(status: str) -> str:
    """Get CSS class based on plan status"""
    status_classes = {
        "completed": "completed",
        "in_progress": "in-progress", 
        "pending": "pending",
        "failed": "failed",
        "cancelled": "cancelled"
    }
    return status_classes.get(status.lower(), "pending")