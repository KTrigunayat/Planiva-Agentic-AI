"""
Helper utilities for the Streamlit GUI
"""
import re
from datetime import datetime, date
from typing import Any, Dict, List, Optional, Union
import streamlit as st

def format_currency(amount: Union[int, float], currency: str = "USD") -> str:
    """Format a number as currency"""
    if currency == "USD":
        return f"${amount:,.2f}"
    return f"{amount:,.2f} {currency}"

def validate_email(email: str) -> bool:
    """Validate email format"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_phone(phone: str) -> bool:
    """Validate phone number format"""
    # Remove all non-digit characters
    digits = re.sub(r'\D', '', phone)
    # Check if it's a valid length (10-15 digits)
    return 10 <= len(digits) <= 15

def format_date(date_obj: Union[date, datetime, str]) -> str:
    """Format date for display"""
    if isinstance(date_obj, str):
        try:
            date_obj = datetime.fromisoformat(date_obj.replace('Z', '+00:00'))
        except:
            return date_obj
    
    if isinstance(date_obj, datetime):
        return date_obj.strftime("%B %d, %Y")
    elif isinstance(date_obj, date):
        return date_obj.strftime("%B %d, %Y")
    
    return str(date_obj)

def safe_get(dictionary: Dict, key: str, default: Any = None) -> Any:
    """Safely get a value from a dictionary"""
    try:
        keys = key.split('.')
        value = dictionary
        for k in keys:
            value = value[k]
        return value
    except (KeyError, TypeError):
        return default

def show_success(message: str):
    """Show a success message"""
    st.success(f"✅ {message}")

def show_error(message: str):
    """Show an error message"""
    st.error(f"❌ {message}")

def show_warning(message: str):
    """Show a warning message"""
    st.warning(f"⚠️ {message}")

def show_info(message: str):
    """Show an info message"""
    st.info(f"ℹ️ {message}")

def init_session_state(key: str, default_value: Any):
    """Initialize a session state variable if it doesn't exist"""
    if key not in st.session_state:
        st.session_state[key] = default_value

def clear_session_state(keys: Optional[List[str]] = None):
    """Clear session state variables"""
    if keys is None:
        # Clear all session state
        for key in list(st.session_state.keys()):
            del st.session_state[key]
    else:
        # Clear specific keys
        for key in keys:
            if key in st.session_state:
                del st.session_state[key]

def get_progress_color(percentage: float) -> str:
    """Get color based on progress percentage"""
    if percentage < 25:
        return "#ff4444"  # Red
    elif percentage < 50:
        return "#ff8800"  # Orange
    elif percentage < 75:
        return "#ffaa00"  # Yellow
    elif percentage < 100:
        return "#00aa00"  # Green
    else:
        return "#0066cc"  # Blue

def truncate_text(text: str, max_length: int = 100) -> str:
    """Truncate text to a maximum length"""
    if len(text) <= max_length:
        return text
    return text[:max_length-3] + "..."

def parse_budget_input(budget_str: str) -> Optional[float]:
    """Parse budget input string to float"""
    if not budget_str:
        return None
    
    # Remove currency symbols and commas
    cleaned = re.sub(r'[$,\s]', '', budget_str)
    
    try:
        return float(cleaned)
    except ValueError:
        return None

def format_file_size(size_bytes: int) -> str:
    """Format file size in human readable format"""
    if size_bytes == 0:
        return "0 B"
    
    size_names = ["B", "KB", "MB", "GB"]
    i = 0
    while size_bytes >= 1024 and i < len(size_names) - 1:
        size_bytes /= 1024.0
        i += 1
    
    return f"{size_bytes:.1f} {size_names[i]}"

def create_download_link(data: str, filename: str, mime_type: str = "text/plain") -> str:
    """Create a download link for data"""
    import base64
    
    b64 = base64.b64encode(data.encode()).decode()
    return f'<a href="data:{mime_type};base64,{b64}" download="{filename}">Download {filename}</a>'

def save_form_data_to_session(form_data: Dict, step: int = 1):
    """Save form data to session state with metadata"""
    st.session_state.form_data = form_data
    st.session_state.form_step = step
    st.session_state.form_last_saved = datetime.now()

def load_form_data_from_session() -> tuple[Dict, int]:
    """Load form data from session state"""
    form_data = st.session_state.get('form_data', {})
    form_step = st.session_state.get('form_step', 1)
    return form_data, form_step

def get_form_completion_percentage(form_data: Dict) -> float:
    """Calculate form completion percentage based on required fields"""
    required_fields = [
        'client_name', 'event_type', 'event_date', 'location', 
        'total_guests', 'total_budget'
    ]
    
    completed_fields = sum(1 for field in required_fields if form_data.get(field))
    return (completed_fields / len(required_fields)) * 100

def validate_form_section(section_data: Dict, section_number: int) -> tuple[bool, List[str]]:
    """Validate a specific form section"""
    from utils.validators import EventPlanValidator
    
    errors = []
    
    if section_number == 1:
        errors.extend(EventPlanValidator.validate_basic_info(section_data))
    elif section_number == 2:
        errors.extend(EventPlanValidator.validate_guest_info(section_data))
    elif section_number == 3:
        errors.extend(EventPlanValidator.validate_budget_info(section_data))
    else:
        errors.extend(EventPlanValidator.validate_preferences(section_data))
    
    return len(errors) == 0, errors

def format_form_summary(form_data: Dict) -> str:
    """Format form data as a readable summary"""
    summary_lines = []
    
    # Basic info
    if form_data.get('client_name'):
        summary_lines.append(f"Client: {form_data['client_name']}")
    if form_data.get('event_type'):
        summary_lines.append(f"Event Type: {form_data['event_type']}")
    if form_data.get('event_date'):
        summary_lines.append(f"Date: {format_date(form_data['event_date'])}")
    if form_data.get('location'):
        summary_lines.append(f"Location: {form_data['location']}")
    
    # Guest and budget info
    if form_data.get('total_guests'):
        summary_lines.append(f"Guests: {form_data['total_guests']}")
    if form_data.get('total_budget'):
        summary_lines.append(f"Budget: {format_currency(form_data['total_budget'])}")
    
    # Key preferences
    if form_data.get('venue_types'):
        summary_lines.append(f"Venue Types: {', '.join(form_data['venue_types'])}")
    if form_data.get('cuisine_preferences'):
        summary_lines.append(f"Cuisine: {', '.join(form_data['cuisine_preferences'])}")
    
    return '\n'.join(summary_lines)

def export_form_to_json(form_data: Dict) -> str:
    """Export form data to JSON string"""
    import json
    
    export_data = {
        'form_data': form_data,
        'exported_at': datetime.now().isoformat(),
        'version': '1.0',
        'app': 'Event Planning Agent GUI'
    }
    
    return json.dumps(export_data, indent=2, default=str)

def import_form_from_json(json_str: str) -> Optional[Dict]:
    """Import form data from JSON string"""
    import json
    
    try:
        data = json.loads(json_str)
        if 'form_data' in data:
            return data['form_data']
        return data
    except json.JSONDecodeError:
        return None

def get_section_icon(section_number: int) -> str:
    """Get icon for form section"""
    icons = {
        1: "📋",  # Basic Information
        2: "👥",  # Guest Information
        3: "💰",  # Budget & Priorities
        4: "🏛️", # Venue Preferences
        5: "🍽️", # Catering Preferences
        6: "📸",  # Photography & Services
        7: "✨"   # Client Vision & Theme
    }
    return icons.get(section_number, "📄")

def create_form_progress_bar(current_step: int, total_steps: int) -> str:
    """Create a visual progress bar for the form"""
    progress = (current_step - 1) / total_steps
    filled_blocks = int(progress * 20)  # 20 character progress bar
    empty_blocks = 20 - filled_blocks
    
    progress_bar = "█" * filled_blocks + "░" * empty_blocks
    percentage = int(progress * 100)
    
    return f"Progress: [{progress_bar}] {percentage}% (Step {current_step}/{total_steps})"