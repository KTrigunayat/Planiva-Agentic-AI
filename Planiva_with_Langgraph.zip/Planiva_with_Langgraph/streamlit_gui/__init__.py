"""
Streamlit GUI for Event Planning Agent v2
"""

__version__ = "1.0.0"