"""
Test suite for event planning system
"""