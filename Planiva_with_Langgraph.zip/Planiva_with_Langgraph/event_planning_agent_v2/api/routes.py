"""
FastAPI routes for Event Planning Agent v2
"""

import logging
from fastapi import APIRouter, HTTPException, Depends, BackgroundTasks, Query
from fastapi.responses import JSONResponse
from typing import Dict, Any, Optional, List
from datetime import datetime
from uuid import uuid4
import asyncio

from .schemas import (
    EventPlanRequest, EventPlanResponse, CombinationSelection,
    ErrorResponse, HealthResponse, PlanListResponse, AsyncTaskResponse,
    PlanStatus, WorkflowStatus, EventCombination
)
from ..workflows.execution_engine import (
    get_execution_engine, ExecutionConfig, ExecutionMode,
    execute_event_planning_workflow, get_workflow_status,
    resume_event_planning_workflow, cancel_workflow
)
from ..database.state_manager import get_state_manager
from ..config.settings import get_settings
from .crew_integration import (
    execute_event_planning, generate_event_blueprint,
    get_planning_workflow_status, cancel_planning_workflow,
    resume_planning_workflow
)

logger = logging.getLogger(__name__)
router = APIRouter()

# Dependency to get settings
def get_app_settings():
    return get_settings()

# Dependency to get state manager
def get_db_state_manager():
    return get_state_manager()

# Dependency to get execution engine
def get_workflow_engine():
    return get_execution_engine()


@router.get("/", response_model=Dict[str, str])
async def root():
    """Root endpoint"""
    return {
        "message": "Event Planning Agent v2 API",
        "version": "2.0.0",
        "status": "active"
    }


@router.get("/health", response_model=HealthResponse)
async def health_check(
    settings = Depends(get_app_settings),
    state_manager = Depends(get_db_state_manager)
):
    """Health check endpoint"""
    try:
        # Check database connectivity
        db_status = "healthy"
        try:
            state_manager.health_check()
        except Exception as e:
            db_status = f"unhealthy: {str(e)}"
        
        # Check workflow engine
        engine_status = "healthy"
        try:
            engine = get_workflow_engine()
            metrics = engine.get_performance_metrics()
            if metrics["total_executions"] > 0 and metrics["success_rate"] < 0.5:
                engine_status = "degraded"
        except Exception as e:
            engine_status = f"unhealthy: {str(e)}"
        
        overall_status = "healthy"
        if "unhealthy" in [db_status, engine_status]:
            overall_status = "unhealthy"
        elif "degraded" in [db_status, engine_status]:
            overall_status = "degraded"
        
        return HealthResponse(
            status=overall_status,
            version="2.0.0",
            components={
                "database": db_status,
                "workflow_engine": engine_status,
                "api": "healthy"
            }
        )
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return HealthResponse(
            status="unhealthy",
            version="2.0.0",
            components={"error": str(e)}
        )


@router.post("/v1/plans", response_model=EventPlanResponse)
async def create_plan(
    request: EventPlanRequest,
    background_tasks: BackgroundTasks,
    async_execution: bool = Query(False, description="Execute workflow asynchronously"),
    settings = Depends(get_app_settings),
    state_manager = Depends(get_db_state_manager)
):
    """
    Create a new event plan
    
    Maintains compatibility with existing request/response format while
    integrating with CrewAI and LangGraph workflow execution.
    """
    try:
        # Generate plan ID
        plan_id = str(uuid4())
        
        logger.info(f"Creating event plan {plan_id} for client {request.clientName}")
        
        # Convert request to internal format
        client_request = request.dict()
        
        # Create initial plan record
        initial_plan = {
            "plan_id": plan_id,
            "status": PlanStatus.PENDING.value,
            "client_name": request.clientName,
            "client_request": client_request,
            "combinations": [],
            "selected_combination": None,
            "final_blueprint": None,
            "workflow_status": {
                "current_step": "initialization",
                "progress_percentage": 0.0,
                "steps_completed": [],
                "estimated_completion": None,
                "error_message": None
            },
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        }
        
        # Save initial state
        state_manager.save_plan(initial_plan)
        
        if async_execution:
            # Execute workflow asynchronously
            execution_config = ExecutionConfig(
                mode=ExecutionMode.ASYNCHRONOUS,
                enable_monitoring=True,
                enable_checkpointing=True
            )
            
            # Start background task
            background_tasks.add_task(
                _execute_workflow_background,
                client_request,
                plan_id,
                execution_config,
                state_manager
            )
            
            # Return immediate response
            return EventPlanResponse(
                plan_id=plan_id,
                status=PlanStatus.PROCESSING,
                client_name=request.clientName,
                combinations=[],
                workflow_status=WorkflowStatus(
                    current_step="initialization",
                    progress_percentage=5.0,
                    steps_completed=["plan_created"]
                ),
                created_at=initial_plan["created_at"],
                updated_at=initial_plan["updated_at"]
            )
        else:
            # Execute workflow synchronously
            execution_config = ExecutionConfig(
                mode=ExecutionMode.SYNCHRONOUS,
                timeout=300.0,  # 5 minutes
                enable_monitoring=True,
                enable_checkpointing=True
            )
            
            # Execute workflow using CrewAI integration
            result = execute_event_planning(
                client_request=client_request,
                plan_id=plan_id,
                async_execution=False
            )
            
            # Convert result to response format
            return _convert_execution_result_to_response(result, state_manager)
            
    except Exception as e:
        logger.error(f"Failed to create plan: {e}")
        raise HTTPException(
            status_code=500,
            detail=ErrorResponse(
                error="plan_creation_failed",
                message=f"Failed to create event plan: {str(e)}",
                details={"client_name": request.clientName}
            ).dict()
        )


@router.get("/v1/plans/{plan_id}", response_model=EventPlanResponse)
async def get_plan(
    plan_id: str,
    include_workflow_details: bool = Query(False, description="Include detailed workflow status"),
    state_manager = Depends(get_db_state_manager)
):
    """
    Get event plan by ID with enhanced status reporting
    
    Provides comprehensive plan status including workflow execution details,
    agent performance metrics, and real-time progress updates.
    """
    try:
        logger.info(f"Retrieving plan {plan_id}")
        
        # Load plan from database
        plan_data = state_manager.load_plan(plan_id)
        if not plan_data:
            raise HTTPException(
                status_code=404,
                detail=ErrorResponse(
                    error="plan_not_found",
                    message=f"Event plan {plan_id} not found"
                ).dict()
            )
        
        # Get workflow status if available
        workflow_status = None
        if include_workflow_details:
            execution_status = get_planning_workflow_status(plan_id)
            if execution_status:
                workflow_status = WorkflowStatus(
                    current_step=execution_status.get("status", "unknown"),
                    progress_percentage=_calculate_progress_percentage(execution_status),
                    steps_completed=execution_status.get("nodes_executed", []),
                    error_message=execution_status.get("error")
                )
        
        # Convert combinations to proper format
        combinations = []
        for combo_data in plan_data.get("combinations", []):
            combinations.append(EventCombination(**combo_data))
        
        selected_combination = None
        if plan_data.get("selected_combination"):
            selected_combination = EventCombination(**plan_data["selected_combination"])
        
        return EventPlanResponse(
            plan_id=plan_id,
            status=PlanStatus(plan_data.get("status", "pending")),
            client_name=plan_data.get("client_name", "Unknown"),
            combinations=combinations,
            selected_combination=selected_combination,
            final_blueprint=plan_data.get("final_blueprint"),
            workflow_status=workflow_status,
            created_at=plan_data.get("created_at", datetime.utcnow()),
            updated_at=plan_data.get("updated_at", datetime.utcnow())
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to retrieve plan {plan_id}: {e}")
        raise HTTPException(
            status_code=500,
            detail=ErrorResponse(
                error="plan_retrieval_failed",
                message=f"Failed to retrieve plan: {str(e)}",
                details={"plan_id": plan_id}
            ).dict()
        )


@router.post("/v1/plans/{plan_id}/select-combination", response_model=EventPlanResponse)
async def select_combination(
    plan_id: str,
    selection: CombinationSelection,
    background_tasks: BackgroundTasks,
    generate_blueprint: bool = Query(True, description="Generate final blueprint"),
    state_manager = Depends(get_db_state_manager)
):
    """
    Select a combination for the event plan
    
    Allows clients to select from available combinations and optionally
    trigger blueprint generation through the Blueprint Agent.
    """
    try:
        logger.info(f"Selecting combination {selection.combination_id} for plan {plan_id}")
        
        # Load existing plan
        plan_data = state_manager.load_plan(plan_id)
        if not plan_data:
            raise HTTPException(
                status_code=404,
                detail=ErrorResponse(
                    error="plan_not_found",
                    message=f"Event plan {plan_id} not found"
                ).dict()
            )
        
        # Find the selected combination
        selected_combo = None
        for combo in plan_data.get("combinations", []):
            if combo.get("combination_id") == selection.combination_id:
                selected_combo = combo
                break
        
        if not selected_combo:
            raise HTTPException(
                status_code=400,
                detail=ErrorResponse(
                    error="combination_not_found",
                    message=f"Combination {selection.combination_id} not found in plan"
                ).dict()
            )
        
        # Update plan with selection
        plan_data["selected_combination"] = selected_combo
        plan_data["status"] = PlanStatus.PROCESSING.value if generate_blueprint else PlanStatus.COMPLETED.value
        plan_data["updated_at"] = datetime.utcnow()
        
        # Add selection metadata
        if selection.notes:
            plan_data["selection_notes"] = selection.notes
        if selection.client_feedback:
            plan_data["client_feedback"] = selection.client_feedback
        
        # Save updated plan
        state_manager.save_plan(plan_data)
        
        if generate_blueprint:
            # Trigger blueprint generation in background
            background_tasks.add_task(
                _generate_blueprint_background,
                plan_id,
                selected_combo,
                state_manager
            )
            
            workflow_status = WorkflowStatus(
                current_step="blueprint_generation",
                progress_percentage=90.0,
                steps_completed=["combination_selected"],
                estimated_completion=datetime.utcnow().replace(microsecond=0)
            )
        else:
            workflow_status = WorkflowStatus(
                current_step="completed",
                progress_percentage=100.0,
                steps_completed=["combination_selected", "plan_finalized"]
            )
        
        return EventPlanResponse(
            plan_id=plan_id,
            status=PlanStatus(plan_data["status"]),
            client_name=plan_data.get("client_name", "Unknown"),
            combinations=[EventCombination(**c) for c in plan_data.get("combinations", [])],
            selected_combination=EventCombination(**selected_combo),
            final_blueprint=plan_data.get("final_blueprint"),
            workflow_status=workflow_status,
            created_at=plan_data.get("created_at", datetime.utcnow()),
            updated_at=plan_data["updated_at"]
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to select combination for plan {plan_id}: {e}")
        raise HTTPException(
            status_code=500,
            detail=ErrorResponse(
                error="combination_selection_failed",
                message=f"Failed to select combination: {str(e)}",
                details={"plan_id": plan_id, "combination_id": selection.combination_id}
            ).dict()
        )


@router.get("/v1/plans", response_model=PlanListResponse)
async def list_plans(
    page: int = Query(1, ge=1, description="Page number"),
    page_size: int = Query(10, ge=1, le=100, description="Page size"),
    status: Optional[PlanStatus] = Query(None, description="Filter by status"),
    client_name: Optional[str] = Query(None, description="Filter by client name"),
    state_manager = Depends(get_db_state_manager)
):
    """List event plans with pagination and filtering"""
    try:
        # Build filters
        filters = {}
        if status:
            filters["status"] = status.value
        if client_name:
            filters["client_name"] = client_name
        
        # Get plans from database
        plans_data, total_count = state_manager.list_plans(
            page=page,
            page_size=page_size,
            filters=filters
        )
        
        # Convert to response format
        plans = []
        for plan_data in plans_data:
            combinations = [EventCombination(**c) for c in plan_data.get("combinations", [])]
            selected_combination = None
            if plan_data.get("selected_combination"):
                selected_combination = EventCombination(**plan_data["selected_combination"])
            
            plans.append(EventPlanResponse(
                plan_id=plan_data["plan_id"],
                status=PlanStatus(plan_data.get("status", "pending")),
                client_name=plan_data.get("client_name", "Unknown"),
                combinations=combinations,
                selected_combination=selected_combination,
                final_blueprint=plan_data.get("final_blueprint"),
                created_at=plan_data.get("created_at", datetime.utcnow()),
                updated_at=plan_data.get("updated_at", datetime.utcnow())
            ))
        
        return PlanListResponse(
            plans=plans,
            total_count=total_count,
            page=page,
            page_size=page_size
        )
        
    except Exception as e:
        logger.error(f"Failed to list plans: {e}")
        raise HTTPException(
            status_code=500,
            detail=ErrorResponse(
                error="plan_listing_failed",
                message=f"Failed to list plans: {str(e)}"
            ).dict()
        )


@router.post("/v1/plans/{plan_id}/resume", response_model=EventPlanResponse)
async def resume_plan(
    plan_id: str,
    background_tasks: BackgroundTasks,
    async_execution: bool = Query(True, description="Resume asynchronously"),
    state_manager = Depends(get_db_state_manager)
):
    """Resume a paused or failed workflow"""
    try:
        logger.info(f"Resuming workflow for plan {plan_id}")
        
        # Check if plan exists
        plan_data = state_manager.load_plan(plan_id)
        if not plan_data:
            raise HTTPException(
                status_code=404,
                detail=ErrorResponse(
                    error="plan_not_found",
                    message=f"Event plan {plan_id} not found"
                ).dict()
            )
        
        if async_execution:
            # Resume asynchronously
            execution_config = ExecutionConfig(
                mode=ExecutionMode.ASYNCHRONOUS,
                enable_monitoring=True,
                enable_checkpointing=True
            )
            
            background_tasks.add_task(
                _resume_workflow_background,
                plan_id,
                execution_config,
                state_manager
            )
            
            # Update status
            plan_data["status"] = PlanStatus.PROCESSING.value
            plan_data["updated_at"] = datetime.utcnow()
            state_manager.save_plan(plan_data)
            
            return EventPlanResponse(
                plan_id=plan_id,
                status=PlanStatus.PROCESSING,
                client_name=plan_data.get("client_name", "Unknown"),
                combinations=[EventCombination(**c) for c in plan_data.get("combinations", [])],
                workflow_status=WorkflowStatus(
                    current_step="resuming",
                    progress_percentage=10.0,
                    steps_completed=["resume_initiated"]
                ),
                created_at=plan_data.get("created_at", datetime.utcnow()),
                updated_at=plan_data["updated_at"]
            )
        else:
            # Resume synchronously
            execution_config = ExecutionConfig(
                mode=ExecutionMode.SYNCHRONOUS,
                timeout=300.0,
                enable_monitoring=True
            )
            
            result = resume_planning_workflow(plan_id, async_execution=False)
            return _convert_execution_result_to_response(result, state_manager)
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to resume plan {plan_id}: {e}")
        raise HTTPException(
            status_code=500,
            detail=ErrorResponse(
                error="plan_resume_failed",
                message=f"Failed to resume plan: {str(e)}",
                details={"plan_id": plan_id}
            ).dict()
        )


@router.delete("/v1/plans/{plan_id}")
async def cancel_plan(
    plan_id: str,
    state_manager = Depends(get_db_state_manager)
):
    """Cancel an active workflow execution"""
    try:
        logger.info(f"Cancelling plan {plan_id}")
        
        # Cancel workflow execution
        cancelled = cancel_planning_workflow(plan_id)
        
        if cancelled:
            # Update plan status
            plan_data = state_manager.load_plan(plan_id)
            if plan_data:
                plan_data["status"] = PlanStatus.CANCELLED.value
                plan_data["updated_at"] = datetime.utcnow()
                state_manager.save_plan(plan_data)
            
            return {"message": f"Plan {plan_id} cancelled successfully"}
        else:
            return {"message": f"Plan {plan_id} was not actively running"}
            
    except Exception as e:
        logger.error(f"Failed to cancel plan {plan_id}: {e}")
        raise HTTPException(
            status_code=500,
            detail=ErrorResponse(
                error="plan_cancellation_failed",
                message=f"Failed to cancel plan: {str(e)}",
                details={"plan_id": plan_id}
            ).dict()
        )


# Background task functions
async def _execute_workflow_background(
    client_request: Dict[str, Any],
    plan_id: str,
    config: ExecutionConfig,
    state_manager
):
    """Execute workflow in background"""
    try:
        result = execute_event_planning(client_request, plan_id, async_execution=True)
        
        # Update plan with results
        plan_data = state_manager.load_plan(plan_id)
        if plan_data:
            if result.success and result.final_state:
                plan_data["status"] = PlanStatus.COMPLETED.value
                plan_data["combinations"] = result.final_state.get("beam_candidates", [])
            else:
                plan_data["status"] = PlanStatus.FAILED.value
                plan_data["error_message"] = result.error
            
            plan_data["updated_at"] = datetime.utcnow()
            state_manager.save_plan(plan_data)
            
    except Exception as e:
        logger.error(f"Background workflow execution failed for plan {plan_id}: {e}")
        # Update plan with error
        plan_data = state_manager.load_plan(plan_id)
        if plan_data:
            plan_data["status"] = PlanStatus.FAILED.value
            plan_data["error_message"] = str(e)
            plan_data["updated_at"] = datetime.utcnow()
            state_manager.save_plan(plan_data)


async def _resume_workflow_background(
    plan_id: str,
    config: ExecutionConfig,
    state_manager
):
    """Resume workflow in background"""
    try:
        result = resume_planning_workflow(plan_id, async_execution=True)
        
        # Update plan with results
        plan_data = state_manager.load_plan(plan_id)
        if plan_data:
            if result.success and result.final_state:
                plan_data["status"] = PlanStatus.COMPLETED.value
                plan_data["combinations"] = result.final_state.get("beam_candidates", [])
            else:
                plan_data["status"] = PlanStatus.FAILED.value
                plan_data["error_message"] = result.error
            
            plan_data["updated_at"] = datetime.utcnow()
            state_manager.save_plan(plan_data)
            
    except Exception as e:
        logger.error(f"Background workflow resume failed for plan {plan_id}: {e}")


async def _generate_blueprint_background(
    plan_id: str,
    selected_combination: Dict[str, Any],
    state_manager
):
    """Generate blueprint in background"""
    try:
        # Use CrewAI Blueprint Agent to generate blueprint
        blueprint = generate_event_blueprint(plan_id, selected_combination)
        
        # Fallback to simple blueprint if agent fails
        if not blueprint:
            blueprint = f"""
Event Blueprint for Plan {plan_id}

Selected Vendors:
- Venue: {selected_combination.get('venue', {}).get('name', 'TBD')}
- Caterer: {selected_combination.get('caterer', {}).get('name', 'TBD')}
- Photographer: {selected_combination.get('photographer', {}).get('name', 'TBD')}
- Makeup Artist: {selected_combination.get('makeup_artist', {}).get('name', 'TBD')}

Total Estimated Cost: ₹{selected_combination.get('estimated_cost', 0):,.2f}
Feasibility Score: {selected_combination.get('feasibility_score', 0):.2f}

Generated on: {datetime.utcnow().isoformat()}
            """.strip()
        
        # Update plan with blueprint
        plan_data = state_manager.load_plan(plan_id)
        if plan_data:
            plan_data["final_blueprint"] = blueprint
            plan_data["status"] = PlanStatus.COMPLETED.value
            plan_data["updated_at"] = datetime.utcnow()
            state_manager.save_plan(plan_data)
            
    except Exception as e:
        logger.error(f"Blueprint generation failed for plan {plan_id}: {e}")


def _convert_execution_result_to_response(result, state_manager) -> EventPlanResponse:
    """Convert execution result to API response"""
    plan_data = state_manager.load_plan(result.plan_id)
    
    if not plan_data:
        # Create minimal response from result
        return EventPlanResponse(
            plan_id=result.plan_id,
            status=PlanStatus.COMPLETED if result.success else PlanStatus.FAILED,
            client_name="Unknown",
            combinations=[],
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )
    
    # Convert combinations
    combinations = []
    if result.final_state and result.final_state.get("beam_candidates"):
        for combo in result.final_state["beam_candidates"]:
            combinations.append(EventCombination(**combo))
    
    return EventPlanResponse(
        plan_id=result.plan_id,
        status=PlanStatus.COMPLETED if result.success else PlanStatus.FAILED,
        client_name=plan_data.get("client_name", "Unknown"),
        combinations=combinations,
        workflow_status=WorkflowStatus(
            current_step="completed" if result.success else "failed",
            progress_percentage=100.0 if result.success else 0.0,
            steps_completed=result.nodes_executed,
            error_message=result.error
        ),
        created_at=plan_data.get("created_at", datetime.utcnow()),
        updated_at=datetime.utcnow()
    )


def _calculate_progress_percentage(execution_status: Dict[str, Any]) -> float:
    """Calculate progress percentage from execution status"""
    status = execution_status.get("status", "unknown")
    nodes_executed = len(execution_status.get("nodes_executed", []))
    
    # Rough progress calculation based on typical workflow steps
    total_expected_nodes = 8  # Approximate number of workflow nodes
    
    if status == "completed":
        return 100.0
    elif status == "failed":
        return max(10.0, (nodes_executed / total_expected_nodes) * 100)
    elif status == "running":
        return min(95.0, max(10.0, (nodes_executed / total_expected_nodes) * 100))
    else:
        return 5.0